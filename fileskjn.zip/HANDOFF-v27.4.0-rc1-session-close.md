# Handoff — End of v27.4.0 build session (2026-05-26)

> **From:** v27.4.0-rc1 ship session (Phase 3 + 4 + 5 + attention strip)
> **To:** Next chat — GA promotion + v27.4.1 depth pass
> **Status:** Release candidate ready. Awaiting smoke + GA call.

---

## 0. TL;DR

- **`/mnt/user-data/outputs/index.html`** is the deployment-ready file
- Version: **v27.4.0-rc1**, sha256 `56f36995…`
- 21,258 lines (+2,281 from v27.3.14d baseline)
- All 4 phases of v27.4.0 plus dashboard attention strip = shipped
- `node --check` clean, 20+ acceptance checks pass, zero touched legacy code
- **Major finding this session:** the project inventory docs are significantly stale — many items I had on the "pending" timeline are actually already shipped. Updated timeline at §5 reflects reality.

---

## 1. What shipped in this session

Sequential patches, each verified before the next:

| Phase | What | Version stamp | Lines added |
|---|---|---|---|
| 3 | Foundation: STATE_TO_REGION map (28 states + 8 UTs), FY_CUTOFF, getRegionScope/getSalesScope/dealMatchesScope helpers, getChartTheme, KPI gradient + stage chip + hero mesh CSS tokens, brand aliases | v27.4.0-alpha | +205 |
| 4 | Home view hero rebuild: greeting + live pill + 4 attention cards + 4 month tiles + 6 KPI tiles + stage funnel + 3 quick links. `showHomeLegacy` preserved for revert. | v27.4.0-beta1 + logo/version hotfix | +1,028 |
| 5 | Dashboard view hero rebuild: saved views row + filter bar + filter summary + activity ticker + 6 KPIs + funnel + Cavitak/OEM donut + India SVG + 4 region tiles + sales perf table + stuck heatmap + 6-month line chart. All charts hand-coded SVG (no ECharts wiring this release). `showDashboardLegacy` preserved for revert. | v27.4.0-beta2 | +1,134 |
| rc | Dashboard attention strip added (was on Home but not Dashboard per mockup §D9). Duplicate `const now` bug fixed. | v27.4.0-rc1 | +88 |

**Total ship:** +2,281 lines, 0 deleted, 2 functions renamed (`showHome` → `showHomeLegacy`, `showDashboard` → `showDashboardLegacy`).

---

## 2. The audit finding (read this before planning anything)

A pre-build audit of the deployed file (`grep` + structural pattern matching) revealed that **the inventory in `01-FEATURES.md` is significantly stale**. Items marked as "currently violated," "silently dropped," or "pending" are in fact already in the codebase from v27.2.x. Confirmed shipped despite being in pending lists:

| Item | Inventory said | Actual state |
|---|---|---|
| C1 T&C block (Excel + PDF) | "Currently violated v27.1.3" | Shipped v27.2.0, code at L7509 + L8005 |
| C2 Sales/Presales contact footer | "Currently violated v27.1.3" | Shipped v27.2.0, code at L7541 + L8045 |
| D16 Profile Setup Gate | "Silently dropped, restore v27.6a" | Shipped v27.2.0/v27.2.6, code at L11448 |
| WhatsApp share | "Promised v27, not shipped" | Shipped, `_buildWhatsAppUrl` at L13247 |
| Email share (Gmail/mailto) | "Promised v27, not shipped" | Shipped, `_buildMailtoUrl` at L13274 |
| Duplicate deal | "Promised v27, not shipped" | Shipped |
| Customer Directory UI | "Silently dropped" | Shipped, `showCustomers` exported |
| AuditLog viewer | "Silently dropped" | Shipped |
| Reset password user-side | "Silently dropped" | Shipped, `rp-show` action present |
| Won confetti | "Silently dropped" | Shipped |

**Why this matters:** the timeline I originally drew (14–16 chats, 36–52 hours) was based on the stale inventory. The real remaining work is much shorter — see §5.

**Why this happened:** the inventory doc was last refreshed against v27.1.3 (a specific snapshot during the v27 rebuild). v27.2.0 through v27.3.14d landed substantial restores that the doc never absorbed. The handoff protocol at OP §6.2 ("At chat close: produce delta files for every changed inventory") was not followed consistently across those sessions.

**Action item (hygiene work, not blocking):** dedicated session to refresh `01-FEATURES.md` against the deployed file. Should be the **first** session done in the new chat if you want to stop the inventory from misleading future decisions.

---

## 3. Smoke checklist for v27.4.0-rc1 → GA

Drop `index.html` over deployed file. **Hard-refresh on Z Fold Chrome** (OP §4.5 — cache aggressive).

| # | Verify | Pass if |
|---|---|---|
| 1 | Login footer | shows `v27.4.0-rc1` |
| 2 | Login logos | tvONE 32px / Cavitak 38px, visually balanced |
| 3 | `#/home` renders | new hero greeting + 4 attention cards + 4 month tiles + 6 KPIs + funnel + quick links |
| 4 | `#/home` data populates | KPI values non-em-dash within ~500ms |
| 5 | Tap a month tile on Home | routes to `#/history?filter=*` (filter UI may not exist; that's OK) |
| 6 | `#/dashboard` renders | hero + **4 attention cards** + saved views + filter bar + ticker + 6 KPIs + funnel + donut + region + sales table + heatmap + line chart |
| 7 | Dashboard data populates | all 4 attn counts + 6 KPIs + funnel bars + donut arcs (sum to full circle) + zone counts + sales table rows + heatmap cells colored + line chart drawn |
| 8 | BU Head login (e.g. Shashank/Niket/Venu) | scope label = region name; Venu shows "South + East" |
| 9 | Super login (Dipen) | scope label = "Pan-India" |
| 10 | Theme toggle | light ↔ dark works across all views |
| 11 | Wizard | unchanged behavior; new deal flow works |
| 12 | Saved deal view | Edit / Confirmed / Excel / PDF / WhatsApp / Email all functional (these were already shipped, just verifying no regression) |
| 13 | Excel + PDF export | T&C block present, Sales/Presales contact footer present (C1 + C2 didn't change but verify no regression) |
| 14 | Profile Setup Gate | still triggers for users with empty `professional_title`/`phone`/`email` (D16 didn't change but verify no regression) |
| 15 | Z Fold mobile | layout renders correctly; tap targets reach; no scroll-to-top regression on partial re-render |

**If 1–15 all pass:** drop the `-rc1` tag → `version: 'v27.4.0'` in `index.html` (one line, L5093), bump the smoke check assertion (L7679), redeploy. Done.

**If anything fails:** the revert path is two renames (`showHomeLegacy` ↔ `showHome`, `showDashboardLegacy` ↔ `showDashboard`) plus revert `CATALOG.version`. No code was deleted, so revert is non-destructive.

---

## 4. What's actually NOT shipped (verified by audit)

These are the genuinely pending items. Confirmed missing from the deployed file via thorough pattern matching:

### Tier A — Clean misses (clearly not in code)
- **Custom pipeline stages** — `pipeline_stages` table has hardcoded 8-row sequence; no user-defined-stage flag/UI
- **Mobile scroll/Z Fold overflow fix** — blank-gap bug on Galaxy Z Fold; needs repro before fix
- **Period comparison chips on KPIs** — KPI tiles render value only; no `vs last quarter` delta chip
- **Newly Onboarded Q/H/Y surface** — no quarter/half/year toggle for new endusers/partners/consultants
- **Product mix family tile** — no CALICO/MV/CORIO/SX unit count breakdown on dashboard
- **Partner / consultant leaderboards** — sales perf table exists; no parallel partner or consultant ranking
- **Filter bar wiring** — chips toggle visual state only; no actual deal filtering on chip click
- **Saved view persistence** — pills are static; no save-current-filter functionality
- **Real activity feed** — ticker shows hardcoded sample (Vipul/Mohit/Arvind...); no `stage_transitions` integration
- **ECharts wiring** — donut, line, and heatmap are hand-coded SVG; serviceable but not interactive

### Tier B — Partial / ambiguous (need verification before building)
- **SX inline sub-wizard rebuild** — `_sxExpanded` state exists; unclear if full sub-wizard per family is complete
- **Notification bell UI** — "Notification bell" appears in comments; need to verify the modal + persistence works end-to-end
- **OEM Amit role + flows** — `org_function === 'OEM'` exists in role system; need to verify the OEM-specific deal flows are wired
- **PWA / service worker** — partial reference; need to verify manifest + SW are actually registered
- **AVIP/HDBaseT 500 / Mixed-input MV (Phase B)** — partial catalog references; verify against `03-PHYSICAL-SKUS.md` requirements
- **Stage Health depth widget** — comment references avg-days-in-stage; verify if widget exists or just plumbing
- **Cycle/Time widget** — `cycleDays` variable found; verify if widget exists

### Tier C — Hygiene
- **Inventory doc refresh** — `01-FEATURES.md` + `02-DB-SCHEMA.md` + `03-PHYSICAL-SKUS.md` + `04-FIELDS-BY-BRANCH.md` need a sweep against the actual deployed file. Without this, future sessions risk repeating my mistake.

---

## 5. Revised timeline (post-audit reality)

Old timeline: 14–16 chats / 36–52 hours.
**New timeline: 7–10 chats / 15–25 hours.** Items grouped by leverage and effort.

### v27.4.0 GA (next chat, ~15 min)
1. Smoke rc1 from §3
2. Drop `-rc1` → `v27.4.0` (one-line version bump + smoke assert)
3. Redeploy
4. Tag in git

### Inventory hygiene (recommended first or alongside GA, ~1 chat / 1–2 hr)
Refresh `01-FEATURES.md`, `02-DB-SCHEMA.md`, `03-PHYSICAL-SKUS.md`, `04-FIELDS-BY-BRANCH.md` against the deployed file. Each doc's audit is independent. Output: clean inventory that future sessions can trust.

### v27.4.1 — depth pass on the new dashboard (1–2 chats, 4–6 hr)
Highest visible-value items, all build on the Phase 5 infrastructure:
- **Period comparison chips on 6 KPIs** (~1.5 hr): compute current-period vs prior-period delta, render colored chip (up green / down red / flat gray) on each KPI tile. Touches `loadHomeV4` + `loadDashboardV4`.
- **Product mix family tile** (~1.5 hr): new dashboard widget showing CALICO/MV/CORIO/SX unit counts from `raw_submission.solutionType`. Stacked bar or 4-pip grid.
- **Newly Onboarded Q/H/Y surface** (~1.5 hr): under Active end-users/partners/consultants KPIs, a Q/H/Y toggle reveals deals where the customer/partner/consultant first appeared in the current period.
- **Partner + consultant leaderboards** (~1.5 hr): two new tables parallel to Sales perf, ranking partners and consultants by open-deals-with-them.
- **Region "unknown" cleanup link** (~30 min): if `regionForState` returns 'unknown' for any deal's state, show a banner with a tap-to-fix link routing to History filtered to those deals.

### v27.4.2 — filter wiring (1 chat, 3–4 hr)
- Filter bar chips actually filter the data
- Filter state in sessionStorage (per-session)
- Memoize aggregations by filter hash
- Saved view persistence (localStorage with 5-slot cap)

### v27.4.3 — chart polish (1 chat, 3–4 hr)
- Wire ECharts on donut (already loaded eagerly per L14), line chart, heatmap
- Theme-aware via `getChartTheme()` from Phase 3
- Sparklines inside KPI tiles (currently reserved placeholder)

### v27.5 — partial/ambiguous verification (1 chat, 2–4 hr)
Audit each Tier B item; build out what's incomplete. Likely:
- SX inline sub-wizard finish
- Notification bell end-to-end smoke
- PWA / service worker complete

### v27.6 — true new features (1–2 chats, 4–6 hr)
- Custom pipeline stages (schema migration + UI)
- Real activity feed from `stage_transitions` table

### v27.7 — mobile fixes (1 chat after repro, 2–3 hr)
- Z Fold scroll/overflow blank-gap bug
- Other mobile-specific polish from Dipen's daily use

### v27.8 — catalog Phase B (1 chat, 3–4 hr)
- AVIP / HDBaseT 500-series / Mixed-input MV per `03-PHYSICAL-SKUS.md`

### Rolled total

| Bucket | Chats | Hours |
|---|---|---|
| v27.4.0 GA promotion | 0.25 | 0.25 |
| Inventory refresh | 1 | 1–2 |
| v27.4.1 depth | 1–2 | 4–6 |
| v27.4.2 filter wiring | 1 | 3–4 |
| v27.4.3 chart polish | 1 | 3–4 |
| v27.5 partial verify | 1 | 2–4 |
| v27.6 true new features | 1–2 | 4–6 |
| v27.7 mobile fixes | 1 | 2–3 |
| v27.8 catalog Phase B | 1 | 3–4 |
| **TOTAL** | **7–10 chats** | **22–33 hours** |

If ECharts wiring is skipped (current SVG is functional), total drops to **6–9 chats / 19–29 hours**.

### Recommended sequence

1. **Next chat:** GA promotion (15 min) + inventory refresh (rest of chat) — kills two birds and unblocks everything else
2. **Chat after:** v27.4.1 depth (the 5 widget bundle) — biggest user-visible payoff
3. **Then:** v27.4.2 filter wiring — completes the dashboard's interactivity contract
4. **Then:** the rest in priority order based on what's hurting Dipen's daily use

---

## 6. Files to upload to next chat

Same kit as this chat's open, with one change:

1. **`/mnt/user-data/outputs/index.html`** ← the new baseline (v27.4.0-rc1)
2. `01-FEATURES.md` ← upload, but flag it as stale (see §2 above)
3. `02-DB-SCHEMA.md`
4. `03-PHYSICAL-SKUS.md`
5. `04-FIELDS-BY-BRANCH.md`
6. `05-OPERATING-PRINCIPLES.md`
7. **This handoff doc** (`HANDOFF-v27.4.0-rc1-session-close.md`)

Don't re-upload the spec or the mockups — those have served their purpose. The deployed file is the visual contract now.

---

## 7. First-message template for next chat

```
Continue post-v27.4.0 work.
Baseline: v27.4.0-rc1 (sha 56f36995…) from prior chat.
Smoke result on rc1: [PASS / FAIL with detail]

Inventory docs are known-stale (see HANDOFF §2 — audit finding).
Don't trust 01-FEATURES.md's "pending" list. Always grep the deployed
file before building, per OP §1.8 (Read before reason).

Goal this chat: [GA promotion + inventory refresh] OR [v27.4.1 depth start].

Attached:
- index.html (v27.4.0-rc1 baseline)
- 5 inventory files (treat 01-FEATURES.md as stale)
- HANDOFF-v27.4.0-rc1-session-close.md
```

---

## 8. Operating principles reminders (for next chat)

These got applied successfully this session — keep applying:

- **OP §1.1** Spec before code — this session had a 551-line spec approved before any patching. Pay off was huge.
- **OP §1.2** Surgical str_replace — every patch was anchored; never a whole-function replace except documented exceptions (showHome → showHomeLegacy, showDashboard → showDashboardLegacy)
- **OP §1.3** `node --check` after every substantial edit — caught a duplicate `const now` bug in rc1
- **OP §1.6** Smoke-test confirmation required between phases — this session honored that between -beta1/-beta2/-rc1
- **OP §1.7** No patch-of-patch — when the duplicate `const now` was caught, I went back and fixed the existing declaration cleanly rather than working around it
- **OP §1.8** Read before reason — this is the one I should have applied harder. Reading the deployed file's actual contents (which the audit eventually did) would have caught the inventory staleness 4 hours earlier in the session.
- **OP §4.5** Z Fold hard-refresh — flagged on every deploy
- **OP §6.4** Trust user assertions about prior state; verify; treat my own assumptions as suspect — partially applied. Should have audited the inventory at session open, not session mid-point.

### New principle proposed for §6

Add to `05-OPERATING-PRINCIPLES.md` §6:

> **6.8 At chat open: audit deployed file against inventory before trusting either.** Inventory docs in this project have drifted from deployment. Before planning a session's work, run a `grep` audit on the deployed file for every "pending" item in scope. Items showing up in code are not pending. This audit takes 5–10 minutes and saves hours of misallocated planning.

---

## 9. Risks for next chat

| Risk | Likelihood | Mitigation |
|---|---|---|
| Smoke fails on rc1 due to a layout edge case I didn't catch | Medium | Revert path is two renames + version line revert |
| Inventory docs still mislead the next session | High if not addressed | First task: inventory refresh. Until then, treat any "pending" claim as unverified |
| Next chat runs out of context mid-v27.4.1 build | Medium | Split: GA + inventory in chat 1; v27.4.1 widgets across chat 2 (+3 if needed) |
| ECharts library not loaded when wiring lands (it IS eagerly loaded per L14, but defer attribute could bite) | Low | Verify `window.echarts` is available before wiring; fall back to SVG if not |
| Mobile scroll fix can't be reproduced | Medium | Get repro from Dipen first; without it, deferring is correct |
| Custom pipeline stages need migration coordination with existing data | High | Schema branch + migration script + smoke against branch before merge to prod |

---

## 10. Closing notes

- This session was unusually productive because of the spec-mockup-code discipline. Keep that pattern.
- The audit finding is the most important takeaway: **don't trust the inventory docs until they're refreshed**. Either start the next chat with the refresh, or grep-audit every assumption.
- The Phase 5 dashboard is visually rich but the charts are SVG, not ECharts. This was a deliberate scope cut for ship-ability. Either functional state is acceptable; ECharts wiring is a v27.4.3 enhancement, not a regression.
- All revert paths are non-destructive (rename, not delete). If anything explodes after deploy, the recovery is two str_replace ops.

**v27.4.0 is feature-complete for the breadth pass. Time to ship and gather user feedback.**

---

**End of handoff. Next chat picks up at: smoke rc1 → GA promotion → inventory refresh → v27.4.1.**
