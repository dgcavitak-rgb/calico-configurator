# CORIO Rebuild Spec — v26.7.0

**Generated 2026-05-22 after spec-lock session with Dipenkumar. CORIO has been soft-greyed in production since v25.102.1 pending redesigned recommendation logic. This spec locks the new logic: canvas-count drives chassis selection, separate card catalogs apply to Micro/Mini vs CM2-547-MK2, and several form-row visibility rules vary per chassis tier. Source for catalog SKUs: tvONE master list provided by Dipenkumar 2026-05-22.**

---

## 1. What's in v26.3.1 currently (the gap)

- CORIO wizard not in the v26 layered shell.
- v25.118 had a CORIO wizard with the OLD recommendation logic (`slots ≥ inputs + outputs && max4K ≥ 4K_count`) — **explicitly being replaced** by the canvas-count algorithm in this spec.
- CORIO module catalog from v25.118 used a mixed CORIOmaster/CORIOmatrix SKU list — Dipenkumar 2026-05-22 confirmed CORIOmatrix SKUs (with `-X-` or `-XSC-` in name) are out of scope and provided two separate verified catalogs: Micro/Mini (shared) and CM2-547-MK2 (separate).

**Result:** CORIO is non-functional for new entries in v26 today (only edit-restore on legacy deals works). Lower urgency than CALICO/MV — CORIO is a lower-volume premium path — but locks the v26 rebuild's completion.

---

## 2. Architectural decisions (locked this session)

| Decision | Choice | Rationale |
|---|---|---|
| Chassis selection driver | **Canvas count ONLY** (`f_outputCanvasQty`) — not inputs/outputs | Dipenkumar 2026-05-22 design lock. Inputs/outputs drive *card* selection within the chosen chassis, NOT chassis tier. |
| Card catalogs | **Two separate catalogs**: Micro/Mini (shared) + CM2-547-MK2 (separate). No cross-tier card use. | tvONE hardware reality. |
| CM2-BONDING module | **DROPPED** from spec entirely | Specialty add-on; rep adds manually if needed |
| CPU module | Auto-add 1 per chassis (rep can remove at review); does NOT consume a slot | Dipenkumar 2026-05-22 lock |
| Filter (`CM2-Filter`) | Auto-add 1 per CM2 chassis (no Filter for Micro/Mini) | Dipenkumar 2026-05-22 lock |
| Redundant PSU | Micro/Mini: NO line item (internal, ships with chassis). CM2: user picks via 4-option PSU selector. | Dipenkumar 2026-05-22 lock |
| Blanking panels | Auto-fill remaining empty slots with `CM-BLANK` (Micro/Mini) | Dipenkumar 2026-05-22 lock |
| Per-chassis row visibility | SDI 12G hidden on Micro/Mini · HD-SDI hidden on CM2 | Catalog availability — no card to fulfill |
| Card preference | **Min required first; escalate only when needed** | Dipenkumar 2026-05-22 lock. Smaller card preferred unless qty forces larger. |
| `canvas > 8` path | CM2-547-MK2 + CALICO alternative recommendation card | Dipenkumar 2026-05-22 — both shown as options |

---

## 3. Form architecture

### Card 02 — Input Block (7 rows · same shape as CALICO · row visibility varies per chassis tier)

| # | Label | Field type | Field ID | Range | Micro | Mini | CM2 |
|---|---|---|---|---|---|---|---|
| 1 | HDMI 4K | qty stepper | `f_inputHdmi4kQty` | 0–32 | ✓ | ✓ | ✓ |
| 2 | HDMI FHD | qty stepper | `f_inputHdmiFhdQty` | 0–32 | ✓ | ✓ | ✓ |
| 3 | SDI 12G | qty stepper | `f_inputSdi12gQty` | 0–32 | **hidden** | **hidden** | ✓ |
| 4 | SDI 3G | qty stepper | `f_inputSdi3gQty` | 0–32 | ✓ | ✓ | ✓ |
| 5 | HD-SDI | qty stepper | `f_inputHdsdiQty` | 0–32 | ✓ | ✓ | **hidden** |
| 6 | HDBaseT | qty stepper | `f_inputHdbtQty` | 0–32 | ✓ | ✓ | ✓ |
| 7 | IP Streaming | qty stepper | `f_inputIpQty` | 0–32 | ✓ | ✓ | ✓ |
| 8 | DVI-U | qty stepper | `f_inputDviuQty` | 0–32 | ✓ | ✓ | ✓ |
| 9 | Audio In needed? | Yes/No pill | `f_inputAudio` | yes/no | ✓ | ✓ | ✓ |

**Note:** CALICO has 7 input rows (no HD-SDI, no DVI-U — those signal types are not in the CALICO catalog). CORIO has 9 input rows because the CORIO catalogs include HD-SDI and DVI-U. Some rows hide based on chassis tier (driven by canvas count).

**Chicken-and-egg note:** Chassis tier is determined by canvas count BEFORE inputs are filled. So when the user sets canvas qty, the SDI 12G / HD-SDI rows show/hide accordingly. If user changes canvas qty AFTER filling inputs (changing tier), need to clear any input values for newly-hidden rows.

### Card 03 — Output Block (6 rows + SX trigger)

**Row 0 (CORIO-only — NEW):**

| # | Label | Field type | Field ID | Range | Helper note |
|---|---|---|---|---|---|
| 0 | **Number of Output Canvas** | **qty stepper** | **`f_outputCanvasQty`** | **1–16** | **Drives CORIO chassis selection (§4)** |

**Rows 1–5 (same as CALICO Output Block):**

| # | Label | Field type | Field ID | Range | Helper note |
|---|---|---|---|---|---|
| 1 | Display | qty stepper + 4K/FHD pill | `f_outputDisplayQty` / `f_outputDisplayRes` | 0–32 / 4K\|FHD | Direct-view monitors |
| 2 | Projector | qty stepper + 4K/FHD pill | `f_outputProjectorQty` / `f_outputProjectorRes` | 0–32 / 4K\|FHD | |
| 3 | LED Screens | qty stepper | `f_outputLedQty` | 0–8 (`MAX_SCREENS`) | qty > 0 reveals detail block (same shape as CALICO §5) |
| 4 | 3G-SDI Output | qty stepper | `f_outputSdiQty` | 0–4 | Output SDI |
| 5 | Audio Out needed? | Yes/No pill | `f_outputAudio` | yes/no | Same card as Audio In |

**Conditional row 6 (CM2 only — appears when chassis = CM2-547-MK2):**

| # | Label | Field type | Field ID | Options |
|---|---|---|---|---|
| 6 | Power Supply | dropdown (single-select) | `f_outputCm2Psu` | `CM2-4RPS-1` (1× 400W), `CM2-4RPS-2` (2× 400W, redundant), `CM2-4RPS-700-1` (1× 700W), `CM2-4RPS-700-2` (2× 700W, redundant) — required when CM2 selected |

After all rows: **SX Yes/No pill** (shared with MV/CALICO — see SX-SPEC-v26.6.0).

---

## 4. CORIO chassis selection algorithm (NEW — canvas-driven)

```
INPUT: canvasQty = parseInt(f_outputCanvasQty) ∈ [1, 16]

IF canvasQty == 0:
  return { type: 'empty' }  // user hasn't picked canvas yet

IF canvasQty <= 5:
  chassis = 'C3-503'        // CORIO Micro
  catalog = 'mini-micro'

ELSE IF canvasQty <= 8:
  chassis = 'C3-510'        // CORIO Mini
  catalog = 'mini-micro'

ELSE:  // canvasQty > 8
  chassis = 'CM2-547-MK2'   // CORIOmaster2
  catalog = 'cm2'
  ALSO emit alternative-recommendation card:
    alternative = {
      type: 'CALICO',
      reason: 'Large multi-canvas builds may be served by CALICO PRO C7-PRO-2200 at lower cost. Compare both options with the customer.',
      sku: 'C7-PRO-2200'
    }
```

### Chassis catalog

```javascript
const CHASSIS_CORIO = {
  'C3-503': {
    model: 'CORIO Micro (C3-503)',
    formFactor: '1U',
    slots: 3,
    max4K: 2,
    canvasMin: 1, canvasMax: 5,
    catalog: 'mini-micro',
    psuInternal: true,
    tagline: 'Compact 1U CORIO processor for small-scale jobs (up to 5 canvases).'
  },
  'C3-510': {
    model: 'CORIO Mini (C3-510)',
    formFactor: '2U',
    slots: 10,
    max4K: 4,
    canvasMin: 6, canvasMax: 8,
    catalog: 'mini-micro',
    psuInternal: true,
    tagline: '2U CORIO processor — mid-tier scale (up to 8 canvases).'
  },
  'CM2-547-MK2': {
    model: 'CORIOmaster2 (CM2-547-MK2)',
    formFactor: '4U',
    slots: 14,
    max4K: 8,
    canvasMin: 9, canvasMax: 16,
    catalog: 'cm2',
    psuInternal: false,  // user must pick PSU line item
    tagline: 'Flagship 4U CORIO processor for large multi-canvas builds (9+ canvases).'
  }
};
```

---

## 5. Card catalog A — Micro + Mini (shared)

```javascript
const CORIO_CARDS_MINI_MICRO = {
  // === INPUT CARDS ===
  inputs: {
    'HDMI_4K':  [{ sku: 'CM-HDMI-4K-2IN',     ports: 2, desc: 'CORIOmodule HDMI 4K 2-input (Packaged)' }],
    'HDMI_FHD': [{ sku: 'CM-HDMI-4IN',        ports: 4, desc: 'Quad HDMI 1080P Input module' }],
    'DVI_U':    [{ sku: 'CM-DVIU-2IN',        ports: 2, desc: 'Input module: Dual 2x DVI-U (DVI, HDMI, RGB/YUV, CV, YC) via DVI-I (Packaged)' }],
    // SDI_12G — NO CARD (row hidden in Card 02 for Micro/Mini)
    'SDI_3G':   [{ sku: 'CM-3GSDI-2IN',       ports: 2, desc: 'CORIOmodule 3G SDI 2 input' }],
    'HD_SDI':   [{ sku: 'CM-HDSDI-4IN',       ports: 4, desc: 'Input Module - 4x HD/SD-SDI via BNC' }],
    'HDBT':     [{ sku: 'CM-HDBT-2IN-1ETH',   ports: 2, desc: 'CORIOmodule HDBT 2-input & Ethernet (Packaged)' }],
    'IP':       [{ sku: 'CM-AVIP-IN-1USB-1ETH', ports: 2, desc: 'CORIOmodule 4K Media Streaming Input 16GB SSD (Packaged)' }],
    'AUDIO':    [{ sku: 'CM-AUD-2IN-4OUT',    ports: 2, desc: 'Audio I/O module - Analog (1xIN, 1xOUT), SPDIF (1xIN, 4xOUT) via Terminal block (Packaged) — F/W M406 or newer needed' }]
  },

  // === OUTPUT CARDS ===
  // Multiple options for HDMI 4K + HDMI FHD — apply min-required preference rule
  outputs: {
    'HDMI_4K':  [
      { sku: 'CM-HDMI-4K-SC-1OUT', ports: 1, desc: 'CORIOmaster HDMI 4K 1-output (Packaged) — Firmware M403 or newer needed', default: true },
      { sku: 'CM-HDMI-4K-SC-2OUT', ports: 2, desc: 'CORIOmodule HDMI 4K 2-output (Packaged)' }
    ],
    'HDMI_FHD': [
      { sku: 'CM-HDMI-SC-4OUT',     ports: 4, desc: 'CORIOmaster HDMI 1080P Quad output module - M412 Firmware', default: true },
      { sku: 'CM-HDMI-SC-2OUT-KEY', ports: 2, desc: 'CORIOmaster HDMI 1080P Dual output keying module' }
    ],
    'DVI_I':    [
      { sku: 'CM-DVI-I-SC-2OUT',  ports: 2, desc: 'Output Module with Scaling: 2x DVI-I (Packaged) — Firmware M403 or newer needed' },
      { sku: 'CM-DVI-I-MON-2OUT', ports: 2, desc: 'Output Module (Monitoring): 2x DVI-I Connectors (Packaged)' }
    ],
    'SDI_3G':   [{ sku: 'CM-3GSDI-SC-2OUT',     ports: 2, desc: 'CORIOmodule 3G SDI 2 output (with Scaler CORIO3) (Packaged) — Firmware M403 or newer needed' }],
    'HDBT':     [{ sku: 'CM-HDBT-SC-2OUT-1ETH', ports: 2, desc: 'CORIOmaster HDBaseT 2 scaled outputs and 1 Ethernet (Packaged) — Firmware M403 or newer needed' }],
    'AUDIO':    [{ sku: 'CM-AUD-2IN-4OUT',     ports: 2, desc: 'Audio I/O module — same card as Audio In' }]
  },

  // === CHASSIS ACCESSORIES (auto-added based on chassis) ===
  accessories: {
    'CPU_503':   { sku: 'CM-C3-503-CPU-HTTPS', desc: 'CORIOmaster micro (C3-503) secure communications (https) CPU module', autoAdd: 'when-chassis-C3-503', consumesSlot: false, qty: 1 },
    'CPU_510':   { sku: 'CM-C3-510-CPU-HTTPS', desc: 'CORIOmaster mini (C3-510) secure communications (https) CPU module (boxed)', autoAdd: 'when-chassis-C3-510', consumesSlot: false, qty: 1 },
    'BLANK':     { sku: 'CM-BLANK',            desc: 'Blanking panel for rear of CORIOmaster chassis, fits all chassis sizes', autoAdd: 'fill-empty-slots', consumesSlot: false }
  }
};
```

---

## 6. Card catalog B — CM2-547-MK2

```javascript
const CORIO_CARDS_CM2 = {
  // === INPUT CARDS ===
  inputs: {
    'HDMI_4K':  [
      { sku: 'CM2-HDMI-4K-2IN', ports: 2, desc: 'CM2 module : HDMI 4K Input 2x', default: true },
      { sku: 'CM2-HDMI-4K-4IN', ports: 4, desc: 'CM2 module : HDMI 4K60 input 4x' }
    ],
    'HDMI_FHD': [{ sku: 'CM2-HDMI-4IN', ports: 4, desc: 'CM2 module : HDMI 1080P Input 4x' }],
    'DVI_U':    [{ sku: 'CM2-DVIU-2IN', ports: 2, desc: 'CM2 module : DVI-U Input 2x (DVI, HDMI, RGB/YUV, CV, YC via DVI-I)' }],
    'SDI_12G':  [{ sku: 'CM2-12GSDI-4IN', ports: 4, desc: 'CM2 module : 12G SDI input 4x' }],
    'SDI_3G':   [{ sku: 'CM2-3GSDI-4IN', ports: 4, desc: 'CM2 module : 3G-SDI Input 4x' }],
    // HD_SDI — NO CARD (row hidden in Card 02 for CM2)
    'HDBT':     [{ sku: 'CM2-HDBT-2IN-1ETH', ports: 2, desc: 'CM2 module : HDBT Input 2x (and Ethernet)' }],
    'IP':       [{ sku: 'CM2-AVIP-IN-1USB-1ETH-128', ports: 2, desc: 'CM2 module : 4K Media Streaming Input 128GB SSD' }],
    'AUDIO':    [{ sku: 'CM2-AUD-2IN-3OUT', ports: 2, desc: 'CM2 module : Audio I/O module - Analog (1xIN, 1xOUT), SPDIF (1xIN, 3xOUT)' }]
  },

  // === OUTPUT CARDS ===
  outputs: {
    'HDMI_4K':  [{ sku: 'CM2-HDMI-4K-4OUT', ports: 4, desc: 'CM2 module : HDMI 4K Output 4x' }],
    'HDMI_FHD': [{ sku: 'CM2-HDMI-HD-8OUT', ports: 8, desc: 'CM2 module : HDMI 1080P Output 8x' }],
    'SDI_12G':  [{ sku: 'CM2-12GSDI-4OUT', ports: 4, desc: 'CM2 module : 12G SDI output 4x' }],
    // SDI_3G, DVI, HDBT outputs — NOT IN CM2 CATALOG
    'AUDIO':    [{ sku: 'CM2-AUD-2IN-3OUT', ports: 2, desc: 'CM2 module : same card as Audio In (1+1 analog, 1+3 SPDIF)' }]
  },

  // === CHASSIS ACCESSORIES ===
  accessories: {
    'CPU_CM2':   { sku: 'CM2-547-MK2-CPU-HTTPS', desc: 'Replacement / Upgrade CPU Module (Upgrade CM2-547 to use V-Series Firmware and CG v4)', autoAdd: 'when-chassis-CM2', consumesSlot: false, qty: 1 },
    'FILTER':    { sku: 'CM2-Filter', desc: 'CORIOmaster2 Fan Filter and fixing kit', autoAdd: 'when-chassis-CM2', consumesSlot: false, qty: 1 },
    'BLANK':     { sku: 'CM-BLANK', desc: 'Blanking panel for rear of CORIOmaster chassis, fits all chassis sizes', autoAdd: 'fill-empty-slots', consumesSlot: false }
    // CM2-BONDING — EXPLICITLY DROPPED (not auto-added, not in catalog for engine)
  },

  // === PSU LINE-ITEM OPTIONS (user-selected via f_outputCm2Psu) ===
  psuOptions: {
    'CM2-4RPS-1':     { sku: 'CM2-4RPS',     qty: 1, label: '1× 400 W (primary only)', desc: 'CM2 400W AC Power Supply' },
    'CM2-4RPS-2':     { sku: 'CM2-4RPS',     qty: 2, label: '2× 400 W (primary + redundant)', desc: 'CM2 400W AC Power Supply' },
    'CM2-4RPS-700-1': { sku: 'CM2-4RPS-700', qty: 1, label: '1× 700 W (primary only)', desc: 'CM2 700W AC Power Supply' },
    'CM2-4RPS-700-2': { sku: 'CM2-4RPS-700', qty: 2, label: '2× 700 W (primary + redundant)', desc: 'CM2 700W AC Power Supply' }
  }
};
```

---

## 7. Card selection algorithm (per signal type, per chassis tier)

```
INPUT: signal, qty, chassis (resolved by §4 from canvasQty)
       catalog = (chassis.catalog == 'cm2') ? CORIO_CARDS_CM2 : CORIO_CARDS_MINI_MICRO

cardOptions = catalog.inputs[signal] OR catalog.outputs[signal]
IF !cardOptions: return null  // signal not supported on this chassis

// Apply min-required preference rule
chosenCard = pickMinCard(cardOptions, qty)
cardsNeeded = ceil(qty / chosenCard.ports)
return { sku: chosenCard.sku, qty: cardsNeeded, desc: chosenCard.desc }

function pickMinCard(cardOptions, qty) {
  if (cardOptions.length === 1) return cardOptions[0];
  // Sort ASC by ports
  const sorted = cardOptions.slice().sort((a, b) => a.ports - b.ports);
  // Honor explicit default flag if present
  const defaultCard = sorted.find(c => c.default === true);
  // Min-required rule: smallest card with ports >= qty
  for (const card of sorted) {
    if (card.ports >= qty) return card;
  }
  // No single card fits (multi-card pack) — pick the largest, qty math handles count
  return sorted[sorted.length - 1];
}
```

**Concrete examples** (CM2 HDMI 4K input):
- qty=1 or qty=2 → `CM2-HDMI-4K-2IN` × 1 (2-port card fits)
- qty=3 → `CM2-HDMI-4K-4IN` × 1 (escalates to 4-port)
- qty=5 → `CM2-HDMI-4K-4IN` × 2 (largest card, 2 cards for 8 ports total)

---

## 8. BoM assembly (after all card selections)

```
bom = []

// 1. Chassis line
bom.push({ family: 'CORIO', category: 'chassis', sku: chassis, qty: 1, desc: chassis.model })

// 2. Auto-added CPU module (does NOT consume slot)
cpuAcc = catalog.accessories[chassis == 'C3-503' ? 'CPU_503' :
                              chassis == 'C3-510' ? 'CPU_510' : 'CPU_CM2']
bom.push({ family: 'CORIO', category: 'accessory', sku: cpuAcc.sku, qty: 1, desc: cpuAcc.desc })

// 3. Auto-added filter (CM2 ONLY)
IF chassis == 'CM2-547-MK2':
  filter = catalog.accessories.FILTER
  bom.push({ family: 'CORIO', category: 'accessory', sku: filter.sku, qty: 1, desc: filter.desc })

// 4. Input cards — iterate all 8 signal types, run §7 algorithm per signal
inputCards = []
totalInputSlots = 0
FOR each signal IN ['HDMI_4K', 'HDMI_FHD', 'DVI_U', 'SDI_12G', 'SDI_3G', 'HD_SDI', 'HDBT', 'IP']:
  qty = parseInt(bd[signal]) || 0
  IF qty == 0: continue
  card = pickCardForSignal(signal, qty, chassis)
  IF !card:
    return { type: 'error', error: `Signal "${signal}" not supported on chassis ${chassis}.` }
  inputCards.push(card)
  totalInputSlots += card.qty
// Audio (separate handling — single card for both in + out)
IF bd.audioNeeded:
  audioCard = catalog.inputs.AUDIO[0]
  inputCards.push({ sku: audioCard.sku, qty: 1, desc: audioCard.desc })
  totalInputSlots += 1
inputCards.forEach(c => bom.push({ family: 'CORIO', category: 'input_card', ...c }))

// 5. Output cards — iterate each output signal type
outputCards = []
totalOutputSlots = 0
hdmiOutputQty = displayQty + projectorQty + ledOutputPorts (if any HDMI)
IF hdmiOutputQty > 0 AND any output is HDMI 4K:
  card = pickCardForSignal('HDMI_4K', hdmiOutputQty, chassis)
  outputCards.push(card); totalOutputSlots += card.qty
... (similarly for HDMI_FHD, SDI_12G, SDI_3G, DVI_I, HDBT)
IF bd.audioOut: (already covered by audio in step 4)
outputCards.forEach(c => bom.push({ family: 'CORIO', category: 'output_card', ...c }))

// 6. Slot check
usedSlots = totalInputSlots + totalOutputSlots
IF usedSlots > chassis.slots:
  concerns.push(`⚠ Configuration uses ${usedSlots} slots but chassis ${chassis} has only ${chassis.slots}. Multi-chassis scenario required.`)

// 7. Blank panels (fill empty slots, Micro/Mini AND CM2)
emptySlots = chassis.slots - usedSlots
IF emptySlots > 0:
  bom.push({ family: 'CORIO', category: 'accessory', sku: 'CM-BLANK', qty: emptySlots,
             desc: 'Blanking panel — auto-filled for empty slot(s)' })

// 8. CM2 PSU (user-selected line item — CM2 ONLY)
IF chassis == 'CM2-547-MK2':
  psuPick = f_outputCm2Psu  // user picks from 4 options
  IF !psuPick:
    return { type: 'error', error: 'Please select a CM2 power supply option.' }
  psuOption = CORIO_CARDS_CM2.psuOptions[psuPick]
  bom.push({ family: 'CORIO', category: 'psu', sku: psuOption.sku, qty: psuOption.qty,
             desc: psuOption.desc + ' (' + psuOption.label + ')' })

// 9. Canvas > 8 — alternative recommendation
IF canvasQty > 8:
  result.alternative = {
    type: 'CALICO',
    reason: 'Large multi-canvas builds may be better served by CALICO PRO C7-PRO-2200 at lower cost. Compare both options with the customer.',
    sku: 'C7-PRO-2200'
  }

return { type: 'corio', chassis, bom, alternative }
```

---

## 9. Acceptance tests

| # | Test | Expected |
|---|---|---|
| 1 | Tiny canvas — canvas=2 + HDMI 4K=2 + Display=1 (4K) | C3-503 + CM-C3-503-CPU-HTTPS + CM-HDMI-4K-2IN × 1 (in) + CM-HDMI-4K-SC-1OUT × 1 (out) + CM-BLANK × 0 (3 slots = 2 used → 1 BLANK actually) |
| 2 | Medium — canvas=7 + HDMI 4K=4 + HDMI FHD=2 + Display=4 (4K) | C3-510 + CM-C3-510-CPU-HTTPS + cards packed in 10 slots |
| 3 | Large — canvas=10 + HDMI 4K=4 + SDI 12G=2 + Display=6 (4K) | CM2-547-MK2 + CM2-547-MK2-CPU-HTTPS + CM2-Filter + cards + PSU line item (user must pick) + alternative CALICO card shown |
| 4 | SDI 12G on Mini — canvas=6 + SDI 12G=2 + Display=2 | ERROR — SDI 12G not supported on Mini (row was hidden in Card 02; user must change canvas to >8 or remove SDI 12G) |
| 5 | HD-SDI on CM2 — canvas=10 + HD-SDI=4 + Display=2 | ERROR — HD-SDI not supported on CM2 (row was hidden) |
| 6 | Min-card preference — canvas=10 + HDMI 4K=2 | CM2-HDMI-4K-2IN × 1 (uses 2-port card, default tag) |
| 7 | Min-card escalation — canvas=10 + HDMI 4K=3 | CM2-HDMI-4K-4IN × 1 (escalates to 4-port; 2-port can't fit 3) |
| 8 | Min-card multi-card — canvas=10 + HDMI 4K=10 | CM2-HDMI-4K-4IN × 3 (largest card, 3 cards for 12 ports) |
| 9 | CPU rep-removable — generate BoM on CM2 + delete CPU line at review | BoM regenerates without CPU; final quote downloads without CPU line |
| 10 | Auto-Filter on CM2 — canvas=12 | CM2-Filter × 1 always in BoM |
| 11 | No Filter on Micro/Mini — canvas=3 | NO CM-Filter line item |
| 12 | Blank panels fill — canvas=2 + HDMI 4K=2 + Display=1 → 3-slot Micro, 2 used | CM-BLANK × 1 (1 empty slot remaining) |
| 13 | CM2 PSU required — canvas=10, leave f_outputCm2Psu unselected → click Generate BoM | ERROR — "Please select a CM2 power supply option" |
| 14 | CM2 PSU 4 options — selector shows 4 entries: 400W×1, 400W×2, 700W×1, 700W×2 |
| 15 | Alternative CALICO card — canvas=12 | Result page shows CORIO recommendation primary + CALICO PRO C7-PRO-2200 alternative-recommendation card below |
| 16 | Canvas-change row visibility — set canvas=12 (CM2 row visible), fill HD-SDI=4, then set canvas=6 (Mini) | HD-SDI row hides; HD-SDI qty value cleared to 0 (or warning surfaced if not cleared) |
| 17 | Slot overflow — canvas=2 + many input cards forcing > 3 slots used | concern surfaced: "uses X slots but chassis has 3" |
| 18 | Edit-restore CORIO deal — save a CM2 deal with PSU=2×700W. Refresh. Edit. | Form populates: canvas qty, all input rows, PSU selector pre-picked to 700W×2 |
| 19 | SX panel — pick SX Yes at bottom of Card 03 | SX panel expands below |
| 20 | BONDING never appears — even with CM2 + all options exercised | No CM2-BONDING line in any BoM |

---

## 10. Save flow + edit-restore

### Save (write side)

`_corioCalculateAndLog()` builds:
1. `header` — submission shape, status = `'viewed'` (NOT `'pending'` per v25.108.3)
2. `lines[]` from BoM — chassis + CPU + Filter (if CM2) + all input/output cards + BLANK + PSU (if CM2)
3. `raw_submission` blob — includes `_inputSignals` (lossless per-signal counts), `_outputBreakdown` (canvas qty, output rows, PSU choice), `_screens` (with pitch)

LED screens write to `deal_screens` separately (one row per screen).

### Edit-restore (read side)

`startEditingSubmission()` for CORIO branch:
1. Select VP family pill + CORIO sub-pill, fire onChange
2. Read `raw_submission._outputBreakdown.canvasQty` → set `f_outputCanvasQty` → triggers chassis-tier resolution → triggers Card 02 row visibility update
3. Read `raw_submission._inputSignals` → populate Card 02 fields (only visible ones for the chassis tier)
4. Read `raw_submission._screens` + `deal_screens` → rebuild LED detail block
5. Read `raw_submission._outputBreakdown` → populate Card 03 5 rows + PSU selector (if CM2)
6. Read `raw_submission._sxCarts` (if present) → repopulate SX window carts
7. Call `_recomputeBreakdown()` at end

---

## 11. Out of scope for v26.7.0

- CALICO wizard (v26.5.0)
- MV wizard (v26.4.0)
- SX panel implementation (v26.6.0)
- CM2-BONDING module (explicitly dropped from spec)
- Multi-chassis CORIO recommendations (single-chassis only; multi-chassis surfaces as concern)
- CORIOmatrix SKUs (`-X-`, `-XSC-` variants — out of scope)

---

## 12. What v26.7.0 ship looks like

1. Add `corioWizardCard` (Card 02 + Card 03 markup per §3) — note: Card 02 row visibility logic depends on chassis tier
2. Reuse LED screens detail block from v26.5 CALICO (no duplication)
3. Insert two card catalogs (`CORIO_CARDS_MINI_MICRO`, `CORIO_CARDS_CM2`) verbatim from §5 + §6 of this doc
4. Insert chassis catalog (`CHASSIS_CORIO`) from §4
5. Insert chassis-selection function (canvas-driven, §4)
6. Insert card-selection function (`pickCardForSignal` + `pickMinCard`, §7)
7. Insert BoM assembler (§8)
8. Insert `_corioCalculateAndLog()` save flow §10
9. Insert CORIO branch in `startEditingSubmission()` §10
10. Wire CM2 PSU selector visibility (show only when chassis == CM2-547-MK2)
11. Wire row visibility logic — SDI 12G hide on mini-micro, HD-SDI hide on CM2 (driven by canvas qty change)
12. Wire SX Yes/No pill at bottom of Card 03 (shared panel from v26.6)
13. Remove the v25.102.1 "Coming soon" soft-grey on the CORIO family pill
14. Bump version `26.6.x` → `26.7.0` with inline changelog
15. `node --check` validation
16. Deliver `index.html` to `/mnt/user-data/outputs/`

**Estimated effort: ~1500 lines net add. No DB schema change. No backend change.**

---

*End of CORIO-SPEC-v26.7.0. Source: voice clarification with Dipenkumar 2026-05-22 + tvONE catalog (Micro/Mini list and CM2 list provided by Dipenkumar).*
