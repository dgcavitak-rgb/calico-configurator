# HANDOFF — v26.6.5 — 2026-05-22

> **For the next chat with Claude.** Paste this whole doc as your first message
> (or attach it). Everything you need to continue is in here. Read top-down.

---

## 0. TL;DR

- **Latest shipped:** `index.html` v26.6.5 — sitting in `/mnt/user-data/outputs/` (your last download)
- **Currently deployed live:** v26.6.1 (per the console log in your last screenshot)
- **Six versions sit between live and latest:** v26.6.2, 6.3, 6.4, 6.5 — all need deploying together since they layer
- **Before doing anything new in the next session:** deploy v26.6.5 and smoke-test the 4 critical paths (see §5)
- **Then start fresh work** from the priorities in §7

---

## 1. What each shipped version did (deploy them all together)

| Version | Headline | Status |
|---|---|---|
| **v26.6.0** | SX panel (HDBaseT, Splitter, AOC, AP-536) + MV/CORIO trigger pills | ✅ deployed live by you |
| **v26.6.1** | `defer` on heavy export libs + preconnects (~1.6 MB off critical path) | ✅ deployed live by you |
| **v26.6.2** | **🔥 CRITICAL** actor_user_id restore on session rehydrate (fixed 400s on every save); MV input UI (3-field layout); SX qty steppers → ± buttons; MV CSS | ⏳ shipped, NOT YET DEPLOYED |
| **v26.6.3** | Home + History dashboards wired to Supabase deal_list (was 100% hardcoded Marriott/Phoenix/Infosys placeholder HTML) + `f_stageNote` hidden field | ⏳ shipped, NOT YET DEPLOYED |
| **v26.6.4** | SX panel always-shows bug fix (now controlled only by Yes/No pill); Sales/Presales dropdowns populate on page reload; Notes reordered to come AFTER wizards (was between Solution Type and Configuration); Save bar 44px tap targets; MV intro trimmed | ⏳ shipped, NOT YET DEPLOYED |
| **v26.6.5** | **LED Screens section now visible** (was hidden by a `'yes'` vs `"Yes"` case-mismatch + missing onchange wire — that's why your `addScreen` UI was nowhere to be found); Output type + Projector res (legacy) hidden; Chrome extension async-response noise filtered; `addScreen` markup rewritten with v26 design tokens; `removeLastScreen` added | ⏳ shipped, NOT YET DEPLOYED |

**File to deploy:** `/mnt/user-data/outputs/index.html` (917 KB, 18,318 lines). Single file. Cmd+S, push to GitHub Pages, done.

---

## 2. The "wrong recommendation" bug from your last screenshot

You picked **3G SDI input + 3G SDI output** in MV mode → got **CORIOview MWP-8H-1Y** (which is 8× HDMI input, 1× 4K HDMI output — completely wrong signal types).

**Root cause:** You are on v26.6.1. In v26.6.1, the MV output dropdown looked like this:

```html
<select id="mv_outputSignal">
  <option value="hdmi">HDMI</option>
  <option value="sdi">SDI</option>
  <option value="hdmi+sdi">HDMI + SDI</option>
</select>
```

But the engine's `CORIOVIEW_OUTPUT_CARDS` lookup keys are `'4K HDMI'`, `'DVI-I'`, `'3G SDI'`, `'HDBaseT'`. The value `"sdi"` doesn't match any of them → engine falls back to default behaviour → wrong card.

**Fixed in v26.6.2.** The new dropdown uses correct value strings (`"4K HDMI"`, `"3G SDI"`, etc.) that match the engine's keys.

**Verification step after deploying v26.6.5:**
1. Create a new quote
2. Solution Type = Multi Viewer
3. Input signal type = `3G-SDI`, Input count = 8
4. Output signal = `3G SDI`
5. Build quote → should now recommend the MWP-MTO custom build OR the right SDI chassis (NOT MWP-8H-1Y)
6. Same test with 4K HDMI input + 4K HDMI output should recommend MWP-8H-1Y (which IS correct for HDMI in/out)

If the recommendation is still wrong after deploying v26.6.5 → the bug is in the engine's `recommendMWP` function itself (L10484), not the form UI. That's a separate investigation.

---

## 3. Critical operating patterns — NEVER reintroduce

These are bugs that have already cost time. Documented to prevent repetition.

### actor_user_id must persist across page reloads
- `_sbCurrentUserId` is set ONLY inside `_sbLogin()` (L7865)
- Session rehydrate path (boot reads FormState from localStorage) MUST also reseat `_sbCurrentUserId = state.user.id`
- v26.6.2 fixed this — `id` now persists on the `currentUser` object via `_sbUserToSheet`
- **Defensive throw** added in `_sbSubmissionToPayload`: if `_sbCurrentUserId` is null, the save fails LOUDLY with "Save blocked: your session lost its user id" instead of silently queueing 5× 400 retries

### `_sbLoadUsers()` must fire on session rehydrate
- v26.6.4 fix — boot now calls it fire-and-forget when restoring session
- Without this, Sales/Presales dropdowns are empty until next login

### SX visibility owned by `_onSxToggle` only
- Do NOT add `sxWizardCard` to any auto-active list
- Do NOT add `style.display` mutations elsewhere
- The trigger pill is the single source of truth

### Select-option text vs value
- `<option>Yes</option>` (no value attr) → `select.value === 'Yes'`
- `<option value="yes">Yes</option>` → `select.value === 'yes'`
- Always lowercase-compare when reading: `String(sel.value || '').toLowerCase() === 'yes'`
- This bug (v26.6.5 fix #1) hid the LED Screens section for a week

### Dropdown value strings must match engine catalog keys EXACTLY
| Catalog | Keys |
|---|---|
| `CORIOVIEW_OUTPUT_CARDS` | `'4K HDMI'`, `'HDMI 1080p'`, `'DVI-I'`, `'3G SDI'` (space), `'HDBaseT'` |
| `MV_QTY_CAP` (input caps) | `'DVI-U'`, `'FHD HDMI'`, `'4K HDMI'`, `'3G-SDI'` (hyphen), `'HD-SDI'`, `'HDBaseT'` |

Note: `3G SDI` (output, space) vs `3G-SDI` (input, hyphen) are DIFFERENT keys for the same physical signal — that's how the engine differentiates input cards from output cards. Don't unify them without a deep refactor.

### Surgical str_replace anchors must be unique
- Every patch script uses `must_replace(s, anchor, replacement, label)` which fails loudly if the anchor count ≠ 1
- If the engine has 2 copies of a function (port + v26 wave), patch BOTH explicitly (e.g. v26.6.5 fix #2 patched both `_onActiveLedToggleTV` copies)

### `node --check` before every ship
- Extract inline JS via Python regex → write to `/tmp/inline.js` → `node --check`
- 17k-line HTML, 2 inline `<script>` blocks
- Has caught ~5 syntax errors in this session alone

---

## 4. Outstanding work — priorities for the next session

### 4a. Bugs to verify after deploying v26.6.5

| Bug | Status | Verify by |
|---|---|---|
| Wrong recommendation (3G SDI → MWP-8H-1Y) | Should auto-resolve | Re-run the recommendation per §2 |
| LED Screens section invisible | Fixed in v26.6.5 | Toggle "Active LED wall? = Yes" → section appears |
| SX panel always shows | Fixed in v26.6.4 | Toggle SX pill No → Yes → No, panel should follow |
| Saves return 400 | Fixed in v26.6.2 | Hard refresh + save a draft, should succeed |
| Home dashboard wrong info (Marriott/Phoenix/Infosys placeholders) | Fixed in v26.6.3 | Visit /home, real deals shown |
| Sales/Presales dropdowns empty | Fixed in v26.6.4 | Hard refresh + open /quote/new, dropdowns populated |
| Notes between Solution Type and Configuration | Fixed in v26.6.4 | Form order: Solution → Configuration → Notes |
| Chrome extension async-response error | Fixed in v26.6.5 | Console silent on this |
| Output type + Projector res (legacy) visible | Fixed in v26.6.5 | Outputs section no longer shows them |

### 4b. Deferred bugs (not yet fixed)

| Bug | Severity | Notes |
|---|---|---|
| Long horizontal bar layout artifact (Image 2 from earlier message) | low | Need DOM-inspector or video capture to repro |
| `updateTotals` null guard warning | low | Non-blocking, already shows placeholder. Wrap `.value` access in null check |
| `_populateRolesTV` race warning | very low | Already shows placeholder. Mostly resolved by v26.6.4 fix |
| MV `recommendMWP` may not handle HD-SDI / AVIP inputs cleanly | unknown | HD-SDI not in `CORIOVIEW_OUTPUT_CARDS`, AVIP not in `MV_QTY_CAP` (defaults to cap 8) |
| `MV_QTY_CAP` missing AVIP entry | low | Add `'AVIP': 4` to the catalog at L7951 |
| The 2 placeholder SKUs in CORIOVIEW_OUTPUT_CARDS | medium | `'HDMI 1080p'` row in v26.6.5 catalog still says "PLACEHOLDER SKU; awaiting tvONE confirmation". Get the real SKU from your rep before customer quotes go out. |

### 4c. Specs locked, code pending

These are spec docs from earlier in this session. Implementation is pending.

| Spec | Status | Estimated effort |
|---|---|---|
| **CALICO v26.5.0** | Spec locked at `today_2/CALICO-SPEC-v26.5.0.md` (21 KB) | 1 focused session |
| **MV v26.4.0** (full wizard) | Partially shipped in v26.6.2 (UI fields). Full wizard rebuild in `today_2/MV-SPEC-v26.4.0-REVISED.md` | 1 session for polish |
| **CORIO v26.7.0** | Spec locked at `today_2/CORIO-SPEC-v26.7.0.md` (23 KB) | 1 focused session |
| **CORIO + CALICO-alt v26.7.2 delta** | Locked at `today_2/CORIO-CALICO-ALT-DELTA-v26.7.2.md` (15 KB) | 0.5 session, follows CORIO base |
| **SX v26.6.0** | ✅ shipped live in v26.6.0 + cleanup in v26.6.5 | Done |
| **Full icon + text reduction sweep** | Not specced. Subjective. | 1 session, with a design pass first |

### 4d. Architecture debt (discussed, not fixed)

User chose Option C earlier: ship patches now, restructure later. Items uncovered:
- Mixed naming: `sxWizardCard` (markup) vs `signalExtensionCard` (old JS refs that pointed nowhere)
- Mixed visibility model: `.wizard-card { display:none }` + `.active` override + `style.display` mirror at L2734
- No global `getVal` helper; `setVal` redefined in 2 scopes
- Forward references with `typeof === 'function'` guards (7 callsites for `_sxCollectAllLines`)
- Cart globals declared inline inside edit-restore
- 3 parallel save flows (`_mvCalculateAndLog`, `_calicoCalculateAndLog`, `_corioCalculateAndLog`)
- Wizards injected via IIFE after load (fragile timing)
- Half-ported wizards (mvWizardCard had only output dropdown until v26.6.2; CALICO wizard card doesn't exist yet)
- Two copies of `_onActiveLedToggleTV` and `_populateRolesTV` (engine port + v26 wave) — need to patch both on any change

---

## 5. Smoke-test checklist after deploying v26.6.5

In order. Stop and report any failure before proceeding.

1. **Hard refresh while logged in** → Home dashboard shows YOUR real deals (not Marriott/Phoenix/Infosys placeholders)
2. **Click any deal** → opens fine, no 400 errors in console
3. **Click "Save draft"** on an edit → succeeds (no `actor_user_id` error)
4. **Open `/quote/new`** → Sales person + Presales person dropdowns populated with real names
5. **Pick Multi Viewer** → CALICO Input signals + Output sections HIDE. MV-specific 3-field layout APPEARS. Notes section is BELOW the Configuration card.
6. **Pick CALICO solution type** → Outputs section appears. Change "Active LED wall?" from No → Yes → LED Screens section appears with Screen 1 row
7. **Type 1920 × 1080 at 2.5 mm pitch** → readout: `1920 × 1080 · 2.07 M px · 1 port` + physical size: `4,800 × 2,700 mm`
8. **Tap + Add screen** → Screen 2 appears. Tap − Remove last → goes back to 1.
9. **SX Yes/No pill** → SX panel shows only when Yes (not always-on)
10. **MV mode: 3G-SDI input + 3G SDI output + 8 inputs** → recommendation should NOT be MWP-8H-1Y (that's HDMI)
11. **Console** → no `actor_user_id` errors, no Chrome extension async-response noise, no `f_stageNote` missing-field warnings

---

## 6. Files this handoff bundles

All files are or were in `/home/claude/today_2/` or `/mnt/user-data/outputs/`. The next chat can request any of them if needed:

| File | Bytes | Purpose |
|---|---|---|
| **`index.html`** (v26.6.5) | 917 KB | The live deliverable — 18,318 lines, single-file HTML+JS+CSS |
| `HANDOFF-v26.6.5.md` | (this doc) | Read this first |
| `CALICO-SPEC-v26.5.0.md` | 22 KB | CALICO wizard spec (next implementation target) |
| `CORIO-SPEC-v26.7.0.md` | 24 KB | CORIO wizard spec (after CALICO) |
| `MV-SPEC-v26.4.0-REVISED.md` | 20 KB | MV wizard spec (partial in v26.6.2; polish pending) |
| `SX-SPEC-v26.6.0.md` | 25 KB | SX panel spec (shipped — keep for reference) |
| `CORIO-CALICO-ALT-DELTA-v26.7.2.md` | 15 KB | CORIO recommendations also surface CALICO 1U alt; spec for v26.7.2 |
| `DEV-STATUS-v26-2026-05-22.md` | 13 KB | Pre-session inventory (somewhat outdated by today's 6 ships, but useful for context) |
| `SX-v26.6.0-INTEGRATION-DELTA.md` | 6 KB | How SX spec mapped to actual v26.3.0 file state |
| `apply_v26_6_2.py` through `apply_v26_6_5.py` | 15-24 KB each | Surgical edit scripts (anchored str_replace pattern) — reference for next session's patches |

---

## 7. Recommended opening message for the next chat

```
Hi Claude. Continuing the tvONE Product Selector work from yesterday.

Attached: HANDOFF-v26.6.5.md (read this first), index.html (current latest, v26.6.5), and the 4 spec docs.

Current status:
- v26.6.5 is shipped. I've deployed it live and smoke-tested per §5 of the handoff.
- [REPORT YOUR SMOKE-TEST RESULTS HERE — confirm wrong-rec is fixed, LED screens visible, etc.]

Next priority: [PICK ONE — see §4 of the handoff]
  Option A: CALICO v26.5.0 wizard implementation (spec is locked, ~1 session)
  Option B: CORIO v26.7.0 wizard implementation
  Option C: Investigate any v26.6.5 smoke-test failures first
  Option D: Icon + text-reduction sweep across the app

[STATE YOUR CHOICE]
```

That's a clean opening that re-establishes context and gives the next Claude a clear target.

---

## 8. The one thing I want you to internalize

This session shipped six versions in one chat. That worked because:
- Every fix had a clear anchor in user feedback (screenshot or console log)
- Every patch was anchor-verified before write
- Every ship was `node --check` validated
- Every shipped file had a version bump + inline changelog

It DID NOT work because of marathon stamina. It worked because the discipline above caught problems early.

**For the next session: do that same discipline.** And keep the chats focused — when you hit ship #3 or #4 in one chat, that's the signal to stop, deploy, smoke-test, and open a fresh chat. Cumulative context risk is real and it's silent until it isn't.

---

*End of handoff. — Claude, 2026-05-22, ~05:50 IST*
