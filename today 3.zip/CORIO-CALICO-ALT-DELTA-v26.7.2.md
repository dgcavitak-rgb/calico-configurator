# CORIO + CALICO Alternative Recommendation — Delta on v26.7.0 (v26.7.2)

**Supersedes v26.7.1 (same session, earlier draft). Reflects Dipenkumar's 2026-05-22 feedback on five design calls + multi-chassis-out-of-scope clarification. Applies before v26.5.0 / v26.7.0 implementation.**

---

## 0. Changes from v26.7.1 draft

| Aspect | v26.7.1 draft | v26.7.2 (locked) |
|---|---|---|
| When CALICO alternative emitted | Every CORIO BoM | **CM2 always · Micro/Mini ONLY when CALICO 1U eligible** |
| HD-SDI handling | Surface concern, residual signals go to CALICO engine | **Map to SDI 3G** (3G SDI is backward-compatible with HD-SDI). No concern. |
| Reason copy | Separate for CM2 vs Micro/Mini | **Single copy for both** |
| Canvas-count mismatch concern | Surfaced when `canvas > totalOutputs` | **Dropped** — CALICO has no canvas limitation; canvas = active viewing area |
| Multi-chassis overflow | "Multi-unit required" framing | **"Configuration exceeds single chassis — discuss with PMM"** framing across CORIO + CALICO engines |
| DVI-U handling | Concern surfaced | Unchanged — concern surfaced (no clean SDI-style fallback) |

---

## 1. What changes vs v26.7.0 (base CORIO spec)

| Aspect | v26.7.0 (base) | v26.7.2 (this delta) |
|---|---|---|
| When CALICO alternative emitted | ONLY `canvasQty > 8` (CM2 path) | CM2 always · Micro/Mini ONLY when CALICO 1U eligible |
| CALICO alternative content | Hardcoded `sku: 'C7-PRO-2200'` | Full computed BoM via CALICO engine |
| CALICO chassis choice | N/A (single SKU) | C7-PRO-1200 (1U) when eligible, else C7-PRO-2200 (2U) |
| HD-SDI / DVI-U | N/A | HD-SDI maps to SDI 3G silently; DVI-U surfaced as concern |
| CALICO engine surface | Internal to CALICO wizard | Exposed as pure callable `calicoRecommend(bd, screens)` |
| Multi-chassis overflow | "multi-unit required" | "Configuration exceeds single chassis — discuss with PMM (Dipenkumar)" |

## 2. Why

Dipenkumar 2026-05-22: tvONE is promoting CALICO as the newer-generation product family. Reps should see a real CALICO alternative when CALICO can serve the configuration:
- **CM2 cases**: always show — large multi-canvas builds may be served by CALICO at lower cost.
- **Micro / Mini cases**: show **only when CALICO 1U is viable** — represents a real "smaller, newer alternative". When CALICO would also need 2U (matching or exceeding the CORIO Mini's 2U footprint), the alternative adds noise without insight. No card emitted.

Multi-chassis cascading exists in real hardware but the app does not compute it. When configuration exceeds single-chassis capacity (CORIO OR CALICO), surface a concern that directs the rep to the PMM (Dipenkumar).

---

## 3. Decision-table addition (§2 of v26.7.0)

Append rows:

| Decision | Choice | Rationale |
|---|---|---|
| CALICO alternative emission | CM2 always · Micro/Mini only when CALICO 1U eligible | Dipenkumar 2026-05-22 |
| CALICO alt content | Full computed BoM via reused CALICO engine | Dipenkumar 2026-05-22 — sales fidelity |
| HD-SDI in CALICO mapping | `calBd.sdi3g += corioBd.hdsdi` (backward-compatible) | 3G-SDI is superior to HD-SDI and backward-compatible — Dipenkumar 2026-05-22 |
| DVI-U in CALICO mapping | Not mapped; surface concern | CALICO has no DVI-U card; no clean signal-class fallback |
| Multi-chassis cascading | Out of scope app-side. Concerns direct to PMM. | Dipenkumar 2026-05-22 — real-world is cascadable; tool will not size it. |

---

## 4. Algorithm change — §4 chassis selection (v26.7.0)

**Remove** the inline alternative-emit block at the `canvasQty > 8` branch (lines 102-106 of v26.7.0).

**Remove** the emit in §8 BoM assembler at lines 348-355.

**Replace** with a single call at end of BoM assembly:

```
// After CORIO BoM is built:
result.alternative = buildCalicoAlternative(corioBd, screens, chassis)
// (returns null when no CALICO alt should be shown)
```

---

## 5. NEW §8.5 — `buildCalicoAlternative()` (insert after §8 of v26.7.0)

```
INPUT: corioBd        (CORIO form breakdown — incl. hdsdi, dviu, canvasQty)
        screens        (LED screens array)
        corioChassis   ('C3-503' | 'C3-510' | 'CM2-547-MK2')

// Step 1 — Map CORIO breakdown to CALICO breakdown shape (§6 of CALICO spec)
// HD-SDI inputs fold into SDI 3G (3G-SDI is backward-compatible with HD-SDI)
calBd = {
  hdmi4k:      corioBd.hdmi4k,
  hdmiFhd:     corioBd.hdmiFhd,
  sdi12g:      corioBd.sdi12g,
  sdi3g:       corioBd.sdi3g + corioBd.hdsdi,   // <-- HD-SDI folded into SDI 3G
  hdbt:        corioBd.hdbt,
  ip:          corioBd.ip,
  audioIn:     corioBd.audioIn,
  audioOut:    corioBd.audioOut,
  audioNeeded: corioBd.audioIn || corioBd.audioOut,
  displayQty:    corioBd.displayQty,
  displayRes:    corioBd.displayRes,
  projectorQty:  corioBd.projectorQty,
  projectorRes:  corioBd.projectorRes,
  ledQty:        corioBd.ledQty,
  sdiOutQty:     corioBd.sdiOutQty
}
// NOTE: corioBd.dviu is NOT mapped — no CALICO card. Flagged as concern.

// Step 2 — Pre-flag CORIO-only signal types CALICO can't handle natively
altConcerns = []
IF corioBd.dviu > 0:
  altConcerns.push(
    `CALICO has no DVI-U input card. ${corioBd.dviu} DVI-U source(s) ` +
    `would need conversion to HDMI for the CALICO path.`
  )

// Step 3 — Run CALICO engine (pure callable per §6 of this delta)
calResult = calicoRecommend(calBd, screens)
// Returns: { chassis: 'C7-PRO-1200' | 'C7-PRO-2200', bom: [...], concerns: [...] }
// CALICO 1U auto-selected when v25.99.33 eligibility holds:
//   ALL inputs HDMI · NO audio · ≤6 inputs · ≤2 HDMI outputs · no SDI out

// Step 4 — Emission gate
// CM2 always emits. Micro/Mini emit ONLY if CALICO engine landed on 1U.
shouldEmit = (
  corioChassis === 'CM2-547-MK2'
  OR (
    (corioChassis === 'C3-503' OR corioChassis === 'C3-510')
    AND calResult.chassis === 'C7-PRO-1200'
  )
)
IF NOT shouldEmit:
  return null   // no alternative card rendered

// Step 5 — Compose alternative card (single reason copy)
return {
  type:         'CALICO',
  reason:       'CALICO PRO offers a newer-generation alternative. ' +
                'Compare with the customer.',
  chassis:      calResult.chassis,                  // computed
  chassisModel: CHASSIS[calResult.chassis].model,   // from CALICO §7
  bom:          calResult.bom,                      // full BoM
  concerns:     [...altConcerns, ...(calResult.concerns || [])]
}
```

---

## 6. CALICO engine — structural requirement (amends CALICO-SPEC-v26.5.0)

`recommend()` in CALICO module exposed as pure function `calicoRecommend(bd, screens) → { chassis, bom, concerns }`. No DOM access. No reading of `window._tvInputBreakdownV2580` (caller passes `bd`). Concerns returned in result, not emitted to DOM. Logic per CALICO §8/§9/§10 unchanged — structural requirement only.

---

## 7. Multi-chassis overflow framing (amends CORIO §11 + CALICO §11)

Wherever current spec language says **"multi-unit required"** or **"multi-chassis required"**, replace with:

> *"Configuration exceeds single-chassis capacity. Multi-chassis cascading is supported in hardware but not sized by this tool — discuss with PMM (Dipenkumar) for cascaded sizing."*

Applies to:
- CALICO §10 `pickInputCards()` end — "NOT POSSIBLE in single chassis — slot constraints prevent fit"
- CALICO §9 errors — "Single chassis maxes at 12 HDMI", "SDI_12G 4-OUT card maxes at 4 ports"
- CORIO §8 step 6 — slot overflow concern
- CORIO §11 — `inputsNeeded > 16` and similar

This is a copy change only — no logic change. Existing "NOT POSSIBLE in single chassis" remains the detection trigger; only the surfaced message updates.

---

## 8. UI presentation

Alternative card rendered below primary CORIO recommendation on result page **when `result.alternative != null`**. Same visual shape as primary:

```
┌─ Alternative — CALICO PRO C7-PRO-1200 ──────────────────────────┐
│  <chassis tagline from CHASSIS catalog>                          │
│                                                                  │
│  CALICO PRO offers a newer-generation alternative.               │
│  Compare with the customer.                                      │
│                                                                  │
│  BoM:                                                            │
│  ├─ C7-PRO-1200  × 1                                             │
│  └─ (input cards / output card if any)                           │
│                                                                  │
│  ⚠ Concerns: (only if non-empty)                                 │
│   • CALICO has no DVI-U input card. 2 DVI-U source(s) ...        │
└──────────────────────────────────────────────────────────────────┘
```

When `result.alternative == null` (Micro/Mini case where CALICO 1U not eligible), only the primary CORIO recommendation card renders. No empty placeholder.

---

## 9. Save flow

No DB schema change. Add to `raw_submission`:

```javascript
raw_submission._calicoAlternative =
  result.alternative           // {chassis, bom, concerns} when present
  || null                       // null when not emitted
```

Informational only. Persisted CORIO BoM unchanged. CALICO alt is deterministic from CORIO form — recomputed on edit-restore.

---

## 10. Acceptance tests — append to v26.7.0 §9

| # | Test | Expected |
|---|---|---|
| 21 | All-HDMI Micro 1U-eligible — canvas=2 · HDMI 4K=2 · Display=1 (4K) | Primary: C3-503 Micro. **Alternative card RENDERS: CALICO C7-PRO-1200 (1U)**. No concerns. |
| 22 | Micro 1U-ineligible (SDI input) — canvas=3 · HDMI 4K=2 · SDI 3G=2 · Display=2 | Primary: C3-503 Micro + SDI card. CALICO engine would pick 2U → emission gate fails. **No alternative card rendered.** `_calicoAlternative = null`. |
| 23 | Micro 1U-ineligible (audio) — canvas=2 · HDMI 4K=2 · Display=1 · Audio In=Yes | Primary: C3-503 Micro. CALICO engine picks 2U. **No alternative card.** |
| 24 | Mini 1U-ineligible (>2 outputs) — canvas=7 · HDMI 4K=4 · HDMI FHD=4 · Display=4 (4K) | Primary: C3-510 Mini. CALICO engine picks 2U (4 outputs > 2). **No alternative card.** |
| 25 | Mini 1U-eligible — canvas=8 · HDMI 4K=2 · Display=2 (4K) | Primary: C3-510 Mini. CALICO 1U eligible (all-HDMI, 2 inputs ≤ 6, 2 outputs ≤ 2). **Alternative card RENDERS: C7-PRO-1200.** |
| 26 | CM2 typical — canvas=10 · HDMI 4K=4 · SDI 12G=2 · Display=6 (4K) | Primary: CM2-547-MK2. **Alternative card RENDERS: CALICO C7-PRO-2200** + SDI_12G_4IN HB + HDMI_4K_4OUT Slot 10. |
| 27 | CM2 over CALICO capacity — canvas=14 · HDMI 4K=8 · HDMI FHD=4 · Display=14 (4K) | Primary: CM2-547-MK2. **Alternative card RENDERS: CALICO C7-PRO-2200** with concern: "Configuration exceeds single-chassis capacity. Multi-chassis cascading is supported in hardware but not sized by this tool — discuss with PMM (Dipenkumar)." |
| 28 | CORIO HD-SDI maps to SDI 3G — canvas=3 · HD-SDI=4 · Display=2 (4K) | Primary: C3-503 Micro + HD-SDI card. CALICO alt: `calBd.sdi3g = 0 + 4 = 4` → forces 2U (non-HDMI input) → 1U ineligible → **No alternative card** (Micro/Mini gate). No HD-SDI concern surfaced (silently mapped). |
| 29 | CORIO HD-SDI on CM2 — canvas=10 · HD-SDI=4 · HDMI 4K=2 · Display=2 (4K) | Primary: CM2-547-MK2 + HD-SDI card. **Alternative card RENDERS: CALICO C7-PRO-2200** + SDI_3G_4IN card (4 HD-SDI inputs mapped into SDI 3G). No HD-SDI concern (silent mapping). |
| 30 | CORIO DVI-U on CM2 — canvas=10 · DVI-U=2 · HDMI 4K=2 · Display=2 | Primary: CM2-547-MK2 + DVI-U card. Alternative card RENDERS: CALICO C7-PRO-2200. Concern: "CALICO has no DVI-U input card. 2 DVI-U source(s) would need conversion to HDMI for the CALICO path." |
| 31 | CORIO DVI-U on Mini — canvas=6 · DVI-U=2 · HDMI 4K=2 · Display=4 | Primary: C3-510 Mini + DVI-U card. CALICO engine picks 2U (>2 outputs). **No alternative card** (Micro/Mini gate). DVI-U concern never surfaces because no card emits. |
| 32 | Reason copy unification | Whether alt is rendered from CM2 or from Mini 1U-eligible case, reason text is identical: "CALICO PRO offers a newer-generation alternative. Compare with the customer." |
| 33 | Alt persists across edit-restore | Save canvas=5 CORIO Micro deal (1U-eligible). Refresh. Edit. Result after recompute shows identical CALICO C7-PRO-1200 alternative. |
| 34 | Alt null persists — save Mini deal where CALICO would be 2U. `_calicoAlternative = null` on save. Edit-restore: still null. | No card on either save or restore. |
| 35 | Alt is informational only — never enters `lines[]` | Save CM2 deal → `deal_lines` rows = CM2 BoM only. `raw_submission._calicoAlternative` populated. No CALICO SKUs in `lines[]`. |
| 36 | Multi-chassis copy — force CORIO concern (canvas=2 + many input cards forcing slot overflow) | Concern reads: "Configuration exceeds single-chassis capacity. Multi-chassis cascading is supported in hardware but not sized by this tool — discuss with PMM (Dipenkumar)." |

---

## 11. Out of scope for v26.7.2

- "Switch primary to CALICO" button on the alternative card.
- Symmetric reverse (CORIO alt on CALICO recommendations).
- Pricing comparison between BoMs (CALICO has no prices).
- MV cross-recommendation.
- Multi-chassis cascading sizing in-app (explicitly punted to PMM per §7).

---

## 12. Effort estimate

**Spec lock:** This doc, ready for sign-off.

**Implementation** (after v26.5.0 CALICO + v26.7.0 CORIO base ship):
- Expose `calicoRecommend(bd, screens)` as pure callable — ~30 lines structural.
- Implement `buildCalicoAlternative()` per §5 — ~55 lines (smaller now — no canvas mismatch logic, no HD-SDI concern, simpler reason).
- Multi-chassis copy update across CORIO + CALICO engines (§7) — ~10 lines string-replace.
- Alt-card markup + render with null-guard — ~45 lines (slightly smaller — no canvas concern row).
- Save flow: persist `_calicoAlternative` (or null) — ~5 lines.
- Edit-restore recompute call — ~5 lines.
- Acceptance tests 21-36 manual smoke.

**Net add: ~150 lines.** No DB schema change. No backend change.

---

## 13. What v26.7.2 ship looks like

1. Implement CALICO v26.5.0 with `calicoRecommend(bd, screens)` exposed as pure callable.
2. Implement CORIO v26.7.0 base.
3. Insert `buildCalicoAlternative()` per §5 of this delta into CORIO module.
4. Remove inline `alternative = {...}` blocks from CORIO §4 + §8 (per §4 of this delta).
5. Add `result.alternative = buildCalicoAlternative(corioBd, screens, chassis)` at end of CORIO BoM assembler.
6. Update multi-chassis overflow messages across CORIO + CALICO per §7.
7. Add alt-card markup to CORIO result page with `if (result.alternative != null)` guard.
8. Persist `raw_submission._calicoAlternative` (or null) in CORIO save flow.
9. On CORIO edit-restore, recompute alternative after `_recomputeBreakdown()`.
10. Bump version `26.7.0` → `26.7.2` with inline changelog.
11. `node --check` validation.
12. Deliver `index.html` to `/mnt/user-data/outputs/`.

---

*End of CORIO-CALICO-ALT-DELTA-v26.7.2. Source: voice clarification with Dipenkumar 2026-05-22 — Round 2 feedback locking five design calls + multi-chassis out-of-scope.*
