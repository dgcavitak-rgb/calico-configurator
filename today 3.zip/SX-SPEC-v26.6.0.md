# Signal Extension Rebuild Spec — v26.6.0

**Generated 2026-05-22 after spec-lock session with Dipenkumar. SX (Signal Extension) is a **shared add-on panel** available to both MV and VP (CALICO + CORIO) deals — not its own solution type. Triggered by a Yes/No pill at the bottom of either wizard's last card. The panel below expands with 4 independent sub-wizards (HDBaseT, Splitter, AOC, Audio Extractor). v26.6.0 ports the panel into the v26 layered shell using engine + catalogs verbatim from v25.118.**

---

## 1. What's in v26.3.1 currently (the gap)

- SX panel not in v26 layered shell.
- SX trigger pills exist in mvWizardCard / calicoWizardCard markup (legacy from v25) but the panel they expand isn't ported.
- 4 SX cart arrays (`_sxHdbtCart`, `_sxDaCart`, `_sxAocCart`, `_sxApCart`) exist as window globals in v26.3.1 because the save flow references them, but no UI populates them.
- BoM save/restore for SX lines technically routes through `raw_submission._sxCarts` blob (v25.101.4 lossless pattern) but never has anything to restore.

**Result:** SX is non-functional in v26 today. MV and VP deals cannot include any Signal Extension companion items.

---

## 2. Architectural decisions (locked this session)

| Decision | Choice | Rationale |
|---|---|---|
| Panel hosting | **One shared panel mounted under both MV Card 03 AND VP Card 03** (not duplicated per path) | Dipenkumar 2026-05-22: SX needed for both MV + VP |
| Cart state | **One set of 4 window arrays**, not per-path (`window._sxHdbtCart`, `_sxDaCart`, `_sxAocCart`, `_sxApCart`) | Save flow attaches all 4 carts to any deal regardless of parent path |
| Save persistence | `raw_submission._sxCarts` blob (v25.101.4 lossless path) | Pre-existing pattern; carts also write to `project_lines` with `product_family='Signal Extension'` |
| Edit-restore source | Read from blob FIRST, fall back to `project_lines` only if blob absent (legacy deals) | v25.114 lock |
| Reset behavior | `resetForm()` clears all 4 carts AND re-renders panels | v25.99.29 lock |
| Sub-wizard count | **4** (HDBT extenders, Splitter, AOC, Audio Extractor AP-536) | Locked since v25.99.17 (B3) |
| Family tags | `EXTENDER_HDBASET` / `EXTENDER_SPLITTER` / `EXTENDER_AOC` / `EXTENDER_AUDIO` | Locked since v25.99.17 |
| HDBaseT 500-series (152m FHD) | Deferred to Phase B | Already documented; wizard distance derivation only handles 4K/FHD today |

---

## 3. Panel structure

### Trigger (one pill in each host wizard)

**In `mvWizardCard`** (after output signal dropdown):
```html
<div class="mv-ext-question">
  <label class="mv-ext-label">Required signal extension?</label>
  <div class="pill-group">
    <button class="mv-ext-pill active" data-value="no"  onclick="_onSxToggle('no')">No</button>
    <button class="mv-ext-pill"        data-value="yes" onclick="_onSxToggle('yes')">Yes</button>
  </div>
</div>
```

**In `calicoWizardCard` Card 03 (after row 5):**
Same markup, same `_onSxToggle()` handler.

**In `corioWizardCard` Card 03 (after row 5 / row 6 if CM2):**
Same markup, same `_onSxToggle()` handler.

When any of the 3 triggers is set to "Yes" → shared `#sxPanel` expands.

### `#sxPanel` shared component

Mounted ONCE in the DOM, positioned below the wizards (display:none until any host trigger fires Yes). Contains 4 stacked sub-wizards:

```html
<div class="sx-panel" id="sxPanel" style="display:none">
  <div class="sx-header">
    <h3>Signal Extension</h3>
    <p class="sx-sub">Add HDBaseT extenders, HDMI splitters, AOC cables, or audio extractors to your BoM.</p>
  </div>

  <div class="sx-body" id="sxBody">
    <!-- Sub-wizard 1: HDBaseT -->
    <div class="sx-subwiz" id="sxSubwizHdbt">…</div>

    <!-- Sub-wizard 2: Splitter -->
    <div class="sx-subwiz" id="sxSubwizSplitter">…</div>

    <!-- Sub-wizard 3: AOC -->
    <div class="sx-subwiz" id="sxSubwizAoc">…</div>

    <!-- Sub-wizard 4: Audio Extractor -->
    <div class="sx-subwiz" id="sxSubwizAudio">…</div>
  </div>

  <div class="sx-summary" id="sxSummary">
    <!-- Rebuilt by _sxRebuildSummary() — shows total line count, navigates to BoM -->
  </div>
</div>
```

---

## 4. Sub-wizard 1 — HDBaseT Extenders

### UI (port from v25.118 L8000-L8039)

```
┌─ HDBaseT Extender ──────────────────────────────────────────────┐
│ Magenta HD-One series. 100m at FHD / 60m at 4K. Configure       │
│ one set, click "+ Add" to push to BOM, then configure another.  │
│                                                                  │
│ Signal Type:    [Video / Video+Audio / Video+Audio+IR+RS232]    │
│ Video Res:      [FHD (100m) / 4K UHD (60m)]                     │
│ Transmitters:   [− 0 +]                                          │
│ Receivers:      [− 0 +]                                          │
│                                                                  │
│ [preview: SKU × qty]                                             │
│ [+ Add this HDBaseT extender to BOM]                            │
│                                                                  │
│ Cart:                                                            │
│   3× 2211079-03 — HD-One DX Kit · Video · 100m FHD   [remove]   │
│   2× 2211095-02 — HD-One LX Transmitter · …          [remove]   │
└──────────────────────────────────────────────────────────────────┘
```

### Catalog (verbatim from v25.118 L14013-L14017)

```javascript
const SX_HDBT_MAP = {
  'Video':                { kit: '2211079-03', tx: '2211093-02', rx: '2211094-02', familyLabel: 'HD-One DX' },
  'Video+Audio':          { kit: '2211079-03', tx: '2211093-02', rx: '2211094-02', familyLabel: 'HD-One DX' },
  'Video+Audio+IR+RS232': { kit: '2211078-02', tx: '2211095-02', rx: '2211096-02', familyLabel: 'HD-One LX' }
};
```

Note: Video and Video+Audio use the SAME SKUs (HD-One DX). Video+Audio+IR+RS232 escalates to HD-One LX. This is per tvONE — the DX kit carries both video AND audio over the same HDBaseT signal.

### Cart entry shape

```javascript
window._sxHdbtCart = [];
// Each entry:
{
  family: 'EXTENDER_HDBASET',
  category: 'kit' | 'tx' | 'rx',
  sku: <sku>,
  qty: <int>,
  description: <human-readable>,
  metaJSON: '{"signalType":"Video","videoRes":"FHD","tx":3,"rx":3}'
}
```

### `_sxHdbtAdd()` logic (verbatim from v25.118 L14110-L14145)

```javascript
function _sxHdbtAdd() {
  const sigType = getVal('sx_hdbtSignalType');     // 'Video' | 'Video+Audio' | 'Video+Audio+IR+RS232'
  const videoRes = getVal('sx_hdbtVideoRes');      // 'FHD' | '4K'
  const tx = parseInt(getVal('sx_hdbtTx')) || 0;
  const rx = parseInt(getVal('sx_hdbtRx')) || 0;
  if (tx === 0 && rx === 0) { alert('Set at least one Tx or Rx'); return; }
  const m = SX_HDBT_MAP[sigType];
  const meta = JSON.stringify({ signalType: sigType, videoRes, tx, rx });

  // Kit pattern: when Tx count == Rx count, push as Kit SKU (cheaper than separate Tx + Rx)
  if (tx === rx) {
    window._sxHdbtCart.push({
      family: 'EXTENDER_HDBASET', category: 'kit', sku: m.kit, qty: tx,
      description: `${m.familyLabel} Kit (Tx+Rx+2× PSU) · ${sigType} · ${videoRes === '4K' ? '60m 4K' : '100m FHD'}`,
      metaJSON: meta
    });
  } else {
    // Asymmetric: push Tx and Rx separately
    if (tx > 0) window._sxHdbtCart.push({
      family: 'EXTENDER_HDBASET', category: 'tx', sku: m.tx, qty: tx,
      description: `${m.familyLabel} Transmitter · ${sigType} · ${videoRes === '4K' ? '60m 4K' : '100m FHD'}`,
      metaJSON: meta
    });
    if (rx > 0) window._sxHdbtCart.push({
      family: 'EXTENDER_HDBASET', category: 'rx', sku: m.rx, qty: rx,
      description: `${m.familyLabel} Receiver · ${sigType} · ${videoRes === '4K' ? '60m 4K' : '100m FHD'}`,
      metaJSON: meta
    });
  }
  // Reset form for next add
  setVal('sx_hdbtTx', 0); setVal('sx_hdbtRx', 0);
  _sxRenderHdbtCart();
  _sxRebuildSummary();
}
```

### Remove

```javascript
function _sxHdbtRemove(idx) {
  if (idx >= 0 && idx < window._sxHdbtCart.length) {
    window._sxHdbtCart.splice(idx, 1);
    _sxRenderHdbtCart();
    _sxRebuildSummary();
  }
}
```

---

## 5. Sub-wizard 2 — HDMI Splitter (Distribution Amplifier)

### UI (port from v25.118 L8041-L8068)

```
┌─ HDMI Splitter (Distribution Amplifier) ───────────────────────┐
│ Magenta MG-DA series. All 4K60 HDMI 2.0 with HDCP 2.2 +       │
│ down-scaling. Pick model + qty, click "+ Add".                 │
│                                                                 │
│ Model:    [1×2 (MG-DA-612) / 1×4 (MG-DA-614) / 1×8 (MG-DA-618)]│
│ Quantity: [− 1 +]                                               │
│                                                                 │
│ [+ Add to BOM]                                                  │
│                                                                 │
│ Cart:                                                           │
│   2× MG-DA-614 — 1×4 4K60 HDMI 2.0 Splitter         [remove]   │
└─────────────────────────────────────────────────────────────────┘
```

### Catalog (verbatim from v25.118 L14019-L14024)

```javascript
const SX_DA_MAP = {
  '612': { sku: 'MG-DA-612', desc: '1×2 4K60 HDMI 2.0 Ultra Slim Splitter, HDCP 2.2 + downscaling' },
  '614': { sku: 'MG-DA-614', desc: '1×4 4K60 HDMI 2.0 Ultra Slim Splitter, HDCP 2.2 + downscaling' },
  '618': { sku: 'MG-DA-618', desc: '1×8 4K60 HDMI 2.0 Ultra Slim Splitter, HDCP 2.2 + downscaling' }
};
```

### Cart entry shape

```javascript
window._sxDaCart = [];
// Each entry:
{
  family: 'EXTENDER_SPLITTER',
  category: 'splitter',
  sku: <sku>,
  qty: <int>,
  description: <desc>,
  metaJSON: ''   // splitter has no per-line meta — model is in sku
}
```

### `_sxSplitterAdd()` logic

```javascript
function _sxSplitterAdd() {
  const modelKey = getVal('sx_daModel');   // '612' | '614' | '618'
  const qty = parseInt(getVal('sx_daQty')) || 1;
  if (qty < 1) { alert('Quantity must be at least 1'); return; }
  const spec = SX_DA_MAP[modelKey];
  if (!spec) return;
  // Merge into existing line if same SKU already in cart, else push new
  const existing = window._sxDaCart.find(r => r.sku === spec.sku);
  if (existing) {
    existing.qty += qty;
  } else {
    window._sxDaCart.push({
      family: 'EXTENDER_SPLITTER', category: 'splitter',
      sku: spec.sku, qty: qty, description: spec.desc, metaJSON: ''
    });
  }
  setVal('sx_daQty', 1);
  _sxRenderDaCart();
  _sxRebuildSummary();
}
```

---

## 6. Sub-wizard 3 — AOC (Active Optical Cable)

### UI (port from v25.118 L8070-L8117)

```
┌─ AOC Cable ─────────────────────────────────────────────────────┐
│ Magenta MG-AOC series. 4K60 4:4:4 over fiber.                  │
│                                                                  │
│ Signal:   [HDMI / DisplayPort]                                  │
│ Jacket:   [Std / Plenum / LSZH / Armored]                       │
│ Length:   [select from available lengths for this signal+jacket]│
│ Quantity: [− 1 +]                                                │
│                                                                  │
│ [SKU readout: MG-AOC-661-100M]                                  │
│ [+ Add to BOM]                                                   │
│                                                                  │
│ Cart:                                                            │
│   3× MG-AOC-661-100M — HDMI Std 100m AOC          [remove]      │
└──────────────────────────────────────────────────────────────────┘
```

### Catalog (verbatim from v25.118 L14034-L14047)

```javascript
const SX_AOC_CODE = {
  'HDMI':        { 'Std': '661', 'Plenum': '662', 'LSZH': '663', 'Armored': '66A' },
  'DisplayPort': { 'Std': '881', 'Plenum': '882', 'LSZH': '883', 'Armored': '88A' }
};

const SX_AOC_AVAIL = {
  '661': [10, 15, 20, 25, 30, 40, 50, 60, 70, 100],
  '662': [10, 15, 20, 25, 30, 40, 50, 60, 70, 100],
  '663': [10, 15, 20, 25, 30, 40, 50, 60, 70, 100],
  '66A': [10, 30, 100],
  '881': [10, 15, 20, 25, 30, 40],
  '882': [10, 15, 20, 25, 30, 40],
  '883': [10, 15, 20, 25, 30, 40],
  '88A': [10, 30]
};
```

**SKU pattern:** `MG-AOC-<code>-<length>M`. Example: HDMI Std 30m = `MG-AOC-661-30M`.

**Lengths in meters.** Catalog has gaps — UI must show only available combinations (no length dropdown options that aren't in `SX_AOC_AVAIL[code]`).

### Cart entry shape

```javascript
window._sxAocCart = [];
// Each entry:
{
  family: 'EXTENDER_AOC',
  category: 'aoc',
  sku: <sku>,         // e.g. 'MG-AOC-661-30M'
  qty: <int>,
  description: '<Signal> <Jacket> <length>m Active Optical Cable',
  metaJSON: '{"signal":"HDMI","jacket":"Std","length":30}'
}
```

### `_sxAocAdd()` logic

```javascript
function _sxAocAdd() {
  const signal = getVal('sx_aocSignal');   // 'HDMI' | 'DisplayPort'
  const jacket = getVal('sx_aocJacket');   // 'Std' | 'Plenum' | 'LSZH' | 'Armored'
  const length = parseInt(getVal('sx_aocLength')) || 0;
  const qty = parseInt(getVal('sx_aocQty')) || 1;
  const code = (SX_AOC_CODE[signal] || {})[jacket];
  if (!code) { alert('Invalid signal/jacket combo'); return; }
  const avail = SX_AOC_AVAIL[code] || [];
  if (avail.indexOf(length) < 0) { alert(`${length}m not available for ${signal} ${jacket}. Available: ${avail.join(', ')}m`); return; }
  const sku = `MG-AOC-${code}-${length}M`;
  const desc = `${signal} ${jacket} ${length}m Active Optical Cable`;
  const meta = JSON.stringify({ signal, jacket, length });
  // Merge by SKU
  const existing = window._sxAocCart.find(r => r.sku === sku);
  if (existing) {
    existing.qty += qty;
  } else {
    window._sxAocCart.push({
      family: 'EXTENDER_AOC', category: 'aoc',
      sku, qty, description: desc, metaJSON: meta
    });
  }
  setVal('sx_aocQty', 1);
  _sxRenderAocCart();
  _sxRebuildSummary();
}
```

### Cascade dropdown logic

The length dropdown's options must update when signal or jacket changes:

```javascript
function _sxAocRefreshLengths() {
  const signal = getVal('sx_aocSignal');
  const jacket = getVal('sx_aocJacket');
  const code = (SX_AOC_CODE[signal] || {})[jacket];
  const avail = SX_AOC_AVAIL[code] || [];
  const lengthEl = document.getElementById('sx_aocLength');
  lengthEl.innerHTML = avail.map(L => `<option value="${L}">${L}m</option>`).join('');
}
```

Wire `onchange` on both signal and jacket selects to fire `_sxAocRefreshLengths()`.

---

## 7. Sub-wizard 4 — HDMI Audio Extractor (AP-536)

### UI (port from v25.118 L8118-L8133 — added in v25.99.17)

```
┌─ HDMI Audio Extractor ──────────────────────────────────────────┐
│ tvONE / Magenta AP-536. De-embeds audio from an HDMI stream     │
│ to analog L/R + S/PDIF outputs.                                  │
│                                                                  │
│ Model:    [AP-536 (only option today)]                          │
│ Quantity: [− 1 +]                                                │
│                                                                  │
│ [+ Add to BOM]                                                   │
│                                                                  │
│ Cart:                                                            │
│   2× AP-536 — HDMI Audio Extractor               [remove]       │
└──────────────────────────────────────────────────────────────────┘
```

### Catalog (verbatim from v25.118 L14029-L14031)

```javascript
const SX_AP_MAP = {
  'AP-536': { sku: 'AP-536', desc: 'HDMI Audio Extractor (AP-536) · de-embeds audio to analog L/R + S/PDIF' }
};
```

**Future-proofing:** dropdown stays in case tvONE adds more audio extractor models. For now, one option.

### Cart entry shape

```javascript
window._sxApCart = [];
// Each entry:
{
  family: 'EXTENDER_AUDIO',
  category: 'audio_extractor',
  sku: 'AP-536',
  qty: <int>,
  description: <desc>,
  metaJSON: ''
}
```

**NOTE:** The handoff §10 says `_sxAudioCart` — that's wrong. The actual variable in v25.118 code is `_sxApCart`. Spec follows the code.

### `_sxApAdd()` logic

```javascript
function _sxApAdd() {
  const modelKey = getVal('sx_apModel');   // 'AP-536'
  const qty = parseInt(getVal('sx_apQty')) || 1;
  if (qty < 1) return;
  const spec = SX_AP_MAP[modelKey];
  if (!spec) return;
  const existing = window._sxApCart.find(r => r.sku === spec.sku);
  if (existing) {
    existing.qty += qty;
  } else {
    window._sxApCart.push({
      family: 'EXTENDER_AUDIO', category: 'audio_extractor',
      sku: spec.sku, qty, description: spec.desc, metaJSON: ''
    });
  }
  setVal('sx_apQty', 1);
  _sxRenderApCart();
  _sxRebuildSummary();
}
```

---

## 8. Collect-all-SX-lines (called by save flow)

```javascript
function _sxCollectAllLines() {
  const lines = [];
  // HDBT
  for (const ln of (window._sxHdbtCart || [])) lines.push(ln);
  // Splitter
  for (const ln of (window._sxDaCart || [])) lines.push(ln);
  // AOC
  for (const ln of (window._sxAocCart || [])) lines.push(ln);
  // AP (audio extractor)
  for (const ln of (window._sxApCart || [])) lines.push(ln);
  return lines;
}
```

Save flow (`_mvCalculateAndLog`, `_calicoCalculateAndLog`, `_corioCalculateAndLog`) all call `_sxCollectAllLines()` after their main BoM build. SX lines append to `project_lines` with `product_family = <as-is from cart>` (which is one of `EXTENDER_HDBASET`/`EXTENDER_SPLITTER`/`EXTENDER_AOC`/`EXTENDER_AUDIO`).

---

## 9. Save flow + edit-restore

### Save (`_sbEnrichBlob` — runs at every save)

```javascript
function _sbEnrichBlob(blob) {
  blob._sxCarts = {
    hdbt: (window._sxHdbtCart || []).slice(),
    da:   (window._sxDaCart   || []).slice(),
    aoc:  (window._sxAocCart  || []).slice(),
    ap:   (window._sxApCart   || []).slice()
  };
  return blob;
}
```

Blob writes to `deal_set_raw` RPC alongside the deal save. Also re-enriched at `apiProjectLinesBulkReplace` step for the v25.114 belt-and-braces safety net.

### Edit-restore (`startEditingSubmission`)

```javascript
// SX restore is family-agnostic — runs regardless of MV / CALICO / CORIO
if (_editingOriginalRow._sxCarts) {
  // Lossless path — blob is authoritative
  window._sxHdbtCart = (_editingOriginalRow._sxCarts.hdbt || []).slice();
  window._sxDaCart   = (_editingOriginalRow._sxCarts.da   || []).slice();
  window._sxAocCart  = (_editingOriginalRow._sxCarts.aoc  || []).slice();
  window._sxApCart   = (_editingOriginalRow._sxCarts.ap   || []).slice();
} else {
  // Legacy fallback — rebuild from project_lines (lossy; pre-v25.101.4 deals)
  // ... existing v25.118 line-rebuild logic
}

// Always re-render all 4 panels (v25.114 lock — stale DOM fix)
_sxRenderHdbtCart();
_sxRenderDaCart();
_sxRenderAocCart();
_sxRenderApCart();
_sxRebuildSummary();

// Auto-open SX panel only if any cart has items
const hasSxItems = (window._sxHdbtCart.length || window._sxDaCart.length ||
                    window._sxAocCart.length || window._sxApCart.length);
if (hasSxItems) {
  // Force host trigger pill to Yes and expand panel
  _onSxToggle('yes', { skipPillUpdate: false });
}
```

### Reset (`resetForm`)

```javascript
// v25.99.29 lock — Reset clears all SX carts AND re-renders panels
function resetForm() {
  // ... existing form-clear logic
  window._sxHdbtCart = [];
  window._sxDaCart = [];
  window._sxAocCart = [];
  window._sxApCart = [];
  _sxRenderHdbtCart();
  _sxRenderDaCart();
  _sxRenderAocCart();
  _sxRenderApCart();
  _sxRebuildSummary();
  // Set both host trigger pills to "No"
  _onSxToggle('no');
}
```

---

## 10. Trigger handler

```javascript
function _onSxToggle(value, opts) {
  // value: 'yes' | 'no'
  // Updates all host trigger pills (MV + CALICO + CORIO) and shows/hides #sxPanel.

  const pills = document.querySelectorAll('.mv-ext-pill, .calico-ext-pill, .corio-ext-pill');
  pills.forEach(p => {
    if (p.dataset.value === value) p.classList.add('active');
    else p.classList.remove('active');
  });

  const panel = document.getElementById('sxPanel');
  panel.style.display = (value === 'yes') ? '' : 'none';
}
```

---

## 11. Acceptance tests

| # | Test | Expected |
|---|---|---|
| 1 | MV deal — pick SX Yes at bottom of MV wizard | sxPanel expands below |
| 2 | CALICO deal — pick SX Yes at bottom of Card 03 | same sxPanel expands (not a different one) |
| 3 | CORIO deal — pick SX Yes at bottom of Card 03 | same sxPanel expands |
| 4 | HDBaseT Kit pattern — Signal=Video+Audio, Res=FHD, Tx=3, Rx=3 → Add | 1 cart line: `2211079-03 × 3` HD-One DX Kit |
| 5 | HDBaseT asymmetric — Tx=2, Rx=4 → Add | 2 cart lines: tx-sku × 2 + rx-sku × 4 |
| 6 | HDBaseT signal type → family map — Signal=Video+Audio+IR+RS232 | uses HD-One LX SKUs (2211078-02 / 2211095-02 / 2211096-02) |
| 7 | Splitter merge — pick MG-DA-614 × 2 → Add → pick MG-DA-614 × 1 → Add | 1 cart line: `MG-DA-614 × 3` (qty merged) |
| 8 | Splitter different model — MG-DA-614 × 2 then MG-DA-618 × 1 | 2 cart lines |
| 9 | AOC length filter — Signal=HDMI Std → length dropdown shows [10,15,20,25,30,40,50,60,70,100]; Signal=HDMI Armored → length dropdown shows [10,30,100] |
| 10 | AOC SKU build — HDMI Armored 30m × 1 | cart line: `MG-AOC-66A-30M × 1` |
| 11 | AOC unavailable length — try DisplayPort Std 70m | rejected — only [10,15,20,25,30,40] available for code 881 |
| 12 | AP-536 simple add — AP-536 × 2 → Add → AP-536 × 1 → Add | merged: `AP-536 × 3` |
| 13 | Cross-path save — start MV deal, add HDBT extender, save | deal saved with EXTENDER_HDBASET line in project_lines AND _sxCarts.hdbt in raw_submission |
| 14 | Cross-path edit-restore — edit a CALICO deal that has SX HDBT + Splitter + AOC + AP-536 items | all 4 carts repopulate; panel auto-opens |
| 15 | Stale-DOM fix (v25.114) — edit deal A (no SX items) after editing deal B (with SX items) | panels rebuilt correctly for deal A (empty); no stale data from B |
| 16 | Reset clears carts — fill all 4 sub-wizards → click Reset | all 4 carts empty, panels hidden, trigger pills set to No |
| 17 | Reverse trigger update — open SX from MV trigger (Yes), navigate to CALICO Card 03 → CALICO's trigger pill should show Yes too (synced) | all 3 trigger pills stay in sync |
| 18 | BOM output — SX lines appear in Excel quote under "Companion Items · Signal Extension" section with correct family tags |

---

## 12. Out of scope for v26.6.0

- HDBaseT 500-series (152m FHD) — Phase B, requires wizard distance derivation update
- Fiber MG-FB-* wizard — Phase B
- Encoder-100 (H.264 IP encoder) — Phase B (~40 lines, deferred)
- Pricing for SX items — tvONE has no prices; all SX lines write `line_total_inr = 0`
- AOC additional jacket types beyond Std/Plenum/LSZH/Armored — tvONE catalog
- Custom-length AOC — only catalog lengths supported
- Multiple audio extractor models — only AP-536 today

---

## 13. What v26.6.0 ship looks like

1. Add `#sxPanel` shared component to layered shell (positioned below wizard cards, hidden by default)
2. Insert SX catalog constants (`SX_HDBT_MAP`, `SX_DA_MAP`, `SX_AOC_CODE`, `SX_AOC_AVAIL`, `SX_AP_MAP`) verbatim from §4-§7
3. Insert all 4 sub-wizard UI blocks inside `#sxPanel`
4. Insert all 4 `_sxXxxAdd()` / `_sxXxxRemove()` / `_sxRenderXxxCart()` function families
5. Insert `_sxCollectAllLines()` aggregator and wire into save flow in all 3 host wizards (MV, CALICO, CORIO)
6. Insert `_sxRebuildSummary()` — renders total line count + per-sub-wizard breakdown
7. Insert `_onSxToggle()` — synced trigger handler across MV / CALICO / CORIO host pills
8. Wire `_sbEnrichBlob` to stash `_sxCarts` in raw_submission (engine carry-forward from v25.101.4)
9. Wire `startEditingSubmission` SX restore block (family-agnostic) — blob-first, line-rebuild fallback
10. Wire `resetForm` SX-clear logic
11. Wire trigger pills in mvWizardCard + calicoWizardCard + corioWizardCard
12. Bump version `26.5.x` → `26.6.0` with inline changelog
13. `node --check` validation
14. Deliver `index.html` to `/mnt/user-data/outputs/`

**Estimated effort: ~800 lines net add. No DB schema change. No backend change.**

---

*End of SX-SPEC-v26.6.0. Source: extraction from v25.118.0 git commit 2ba47bb + voice clarification with Dipenkumar 2026-05-22.*
