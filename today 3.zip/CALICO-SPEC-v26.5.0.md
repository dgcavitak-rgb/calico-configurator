# CALICO Rebuild Spec — v26.5.0

**Generated 2026-05-22 after spec-lock session with Dipenkumar. CALICO is the highest-volume revenue path. v26.5.0 ports the wizard into the v26 layered shell using the form shape locked this session and the engine + catalogs verbatim from v25.118 (no logic changes, only shell rebuild). Source line refs are to `v25.118.0.html`.**

---

## 1. What's in v26.3.1 currently (the gap)

- CALICO wizard cards (02 + 03) are **absent** from the v26 layered shell.
- Engine functions (`pickInputCards`, `recommend`, `CHASSIS`, `INPUT_CARDS`, `OUTPUT_CARDS`, `SLOT11_ALLOWED_WHEN_SLOT12`) — **not yet ported**.
- `_tvInputBreakdownV2580` building helper — not yet ported.
- LED screens detail block + `collectScreens()` — not yet ported.

**Result:** CALICO non-functional in v26 today. Volume revenue path blocked.

---

## 2. Architectural decisions (locked this session)

| Decision | Choice | Rationale |
|---|---|---|
| Form field shape — Input Block | 7 per-signal-type qty steppers (HDMI 4K, HDMI FHD, SDI 12G, SDI 3G, HDBaseT, IP, Audio Y/N) | Same as v25.118 v25.80 rebuild. No dropdowns, no row tables. |
| Form field shape — Output Block | 5 per-signal-type rows (Display, Projector, LED, SDI Output, Audio Y/N) parallel to Input shape | New in v26 — symmetric with Input. v25.118 had mixed choice-cards/pills; v26 picks clean parallelism. |
| Hidden compat shims (`f_outputType`, `f_outputSignal`, `f_sdiCount`, `f_projectorCount`, `f_projectorRes`) | **DROPPED** | v26 is a clean rebuild — engine reads new field IDs directly. ~150 fewer lines. |
| Edit-restore for legacy deals | Goes through `raw_submission._inputSignals` blob (v25.101.4 lossless path) | Pre-v25.101.4 deals restore lossily as they already do — no regression. |
| LED screens detail entry | Path 1 — qty > 0 reveals a multi-row detail block; one row per screen with width_px × height_px × pitch_mm | Same shape as v25.118 `addScreen()`. |
| Audio rows | Yes/No pills (in AND out) | Hardware is one fixed card (2-in/4-out); qty stepper would be misleading. |
| Engine catalog source | v25.118.0 verbatim. No changes to chassis / card / slot truth tables. | Hardware reality, not UI choice. tvONE locked. |

---

## 3. Card 02 — Input Block (7 rows)

Each row: `[label] · [qty stepper or Y/N pill] · [helper note]`. Every input change fires `_recomputeBreakdown()` which rebuilds `window._tvInputBreakdownV2580` (engine reads this).

| # | Label | Field type | Field ID | Range | Helper note |
|---|---|---|---|---|---|
| 1 | HDMI 4K | qty stepper | `f_inputHdmi4kQty` | 0–32 | 3840×2160 cameras / sources |
| 2 | HDMI FHD | qty stepper | `f_inputHdmiFhdQty` | 0–32 | 1920×1080 cameras / sources |
| 3 | SDI 12G | qty stepper | `f_inputSdi12gQty` | 0–32 | 12 Gbps SDI (4K) |
| 4 | SDI 3G | qty stepper | `f_inputSdi3gQty` | 0–32 | 3 Gbps SDI (FHD) |
| 5 | HDBaseT | qty stepper | `f_inputHdbtQty` | 0–32 | CAT cable extenders |
| 6 | IP Streaming | qty stepper | `f_inputIpQty` | 0–32 | Network video → maps to MEDIA card |
| 7 | Audio In needed? | Yes/No pill | `f_inputAudio` | yes/no | 1 audio card = 2 in + 4 out |

All qty steppers default `0`. Audio pill defaults `no`.

---

## 4. Card 03 — Output Block (5 rows + SX trigger)

| # | Label | Field type | Field ID | Range | Helper note |
|---|---|---|---|---|---|
| 1 | Display | qty stepper + 4K/FHD pill | `f_outputDisplayQty` / `f_outputDisplayRes` | 0–32 / 4K\|FHD | Direct-view monitors |
| 2 | Projector | qty stepper + 4K/FHD pill | `f_outputProjectorQty` / `f_outputProjectorRes` | 0–32 / 4K\|FHD | |
| 3 | LED Screens | qty stepper | `f_outputLedQty` | 0–8 (`MAX_SCREENS`) | qty > 0 reveals detail block §5 |
| 4 | 3G-SDI Output | qty stepper | `f_outputSdiQty` | 0–4 | Max 4 (SDI 12G 4-OUT card limit) |
| 5 | Audio Out needed? | Yes/No pill | `f_outputAudio` | yes/no | Same card as Audio In |

After the 5 rows: **Signal Extension Yes/No pill** at the bottom. Yes → expands shared SX panel (see SX-SPEC-v26.6.0). SX panel is shared with MV; not duplicated per path.

---

## 5. LED Screens detail block

**Reveals when LED Screens qty > 0.** Bumping qty N → N+1 calls `addScreen()`; N → N-1 calls `removeLastScreen()`. Capped at `MAX_SCREENS = 8`.

### Per-screen row layout (verbatim from v25.118 L11871-L11920)

```
┌─ Screen N ──────────────────────────── — px · — pixels · — ports ┐
│  Resolution Width (px) *   Resolution Height (px) *   LED Pitch (mm)    │
│  [_______________]         [_______________]          [___________]     │
│                                                                          │
│  [if pitch + resolution all set: physical size mm/m readout]            │
└──────────────────────────────────────────────────────────────────────────┘
```

**Fields per row:**
- `resW-{idx}` — number, min 0, required
- `resH-{idx}` — number, min 0, required
- `pitch-{idx}` — number, step 0.01, min 0.3, max 20, optional

**Per-screen readout** (live, in row header):
```javascript
const px     = resW * resH;
const ports  = px > 0 ? Math.ceil(px / PORT_CAPACITY_4K60) : 0;
const PORT_CAPACITY_4K60 = 3840 * 2160; // 8,294,400
// Display: "<resW> × <resH> · <px/1e6 toFixed(2)> M px · <ports> port(s)"
```

**Physical size readout** (shown only when pitch + resolution all set):
```javascript
const widthMm  = Math.round(resW * pitch);
const heightMm = Math.round(resH * pitch);
// "<widthMm> × <heightMm> mm (<widthMm/1000>.XX × <heightMm/1000>.XX m) — at <pitch> mm pitch"
```

### Totals strip (bottom of detail block)

```
LED Pixels: <sum-pixels>      LED Output Ports: <sum-ports>
Projector Ports: <from row 2>  Total Ports Needed: <LED+Projector+Display>
```

**Critical math note:** per-screen port ceiling is taken FIRST, then summed. Ports are NOT shared across screens.

### `collectScreens()` engine contract

```javascript
function collectScreens() {
  const screens = [];
  for (let i = 1; i <= screenCount; i++) {
    const rW = parseInt(getVal('resW-' + i)) || 0;
    const rH = parseInt(getVal('resH-' + i)) || 0;
    const pitch = parseFloat(getVal('pitch-' + i)) || 0;
    const pixels = rW * rH;
    const is4K = rW >= 3840 || rH >= 2160 || pixels >= 8000000;
    const portsForThisScreen = pixels > 0 ? Math.ceil(pixels / PORT_CAPACITY_4K60) : 0;
    const widthMm = pitch > 0 ? Math.round(rW * pitch) : 0;
    const heightMm = pitch > 0 ? Math.round(rH * pitch) : 0;
    screens.push({
      label: 'Screen ' + i, pitch: pitch, resW: rW, resH: rH,
      pixels: pixels, fhdEligible: !is4K && pixels > 0,
      ports: portsForThisScreen, widthMm: widthMm, heightMm: heightMm
    });
  }
  return screens;
}
```

### Persistence

- Each screen → 1 row in `deal_screens` table (`deal_id`, `seq`, `width_px`, `height_px`)
- Pitch isn't in DB schema → stash on `raw_submission._screens[i].pitch`. No schema change.
- Edit-restore reads `deal_screens` for width/height + blob for pitch.

---

## 6. Engine breakdown — `_tvInputBreakdownV2580`

Engine reads `window._tvInputBreakdownV2580` (built by `_recomputeBreakdown()`). Shape:

```javascript
window._tvInputBreakdownV2580 = {
  // Per-signal-type input counts (from Card 02)
  hdmi4k:     <int>,
  hdmiFhd:    <int>,
  sdi12g:     <int>,
  sdi3g:      <int>,
  hdbt:       <int>,
  ip:         <int>,
  audioIn:    <bool>,  // from f_inputAudio pill
  // Output counts (from Card 03)
  displayQty:    <int>,
  displayRes:    '4K' | 'FHD',
  projectorQty:  <int>,
  projectorRes:  '4K' | 'FHD',
  ledQty:        <int>,
  sdiOutQty:     <int>,  // SDI output ports
  audioOut:      <bool>, // from f_outputAudio pill
  audioNeeded:   <bool>  // audioIn || audioOut (engine uses this)
};
```

`_recomputeBreakdown()` is called on every form change AND at the top of `_calculateAndLogImpl` (v25.99.40 lock — never trust `oninput` events to have fired).

---

## 7. Catalog constants (verbatim from v25.118 L10154-L10199)

### CALICO chassis (2)

```javascript
const CHASSIS = {
  'C7-PRO-1200': {
    model: 'CALICO PRO C7-PRO-1200',
    formFactor: '1RU', fixedChassis: true,
    inputs: 6, outputs: 2, maxPortsNative: 2,
    redundantPSU: false,
    tagline: 'Compact 1RU fixed-chassis processor — 6 inputs, 2 outputs.'
  },
  'C7-PRO-2200': {
    model: 'CALICO PRO C7-PRO-2200',
    formFactor: '2RU', fixedChassis: false,
    inputs: 8, outputs: 4, maxPortsNative: 4,
    slots: { output: 1, inputHB: 1, inputLB: 1 },
    redundantPSU: true,
    tagline: '2RU processor — 8 inputs, 4 outputs native. Expandable.'
  }
};

const PORT_CAPACITY_4K60 = 3840 * 2160; // 8,294,400
```

**Hardware truth (LOCKED — do not deviate):**
- **C7-PRO-1200 (1U)** — NO expansion slots. 6× HDMI 4K native inputs (HDMI only — cannot accept SDI/HDBaseT/IP). 2× HDMI 4K native outputs. Cannot do audio.
- **C7-PRO-2200 (2U)** — 8× HDMI 4K-capable native inputs (HDMI-only at native). 4× HDMI 4K native outputs. 3 expansion slots:
  - **Slot 10** (output) — one card (HDMI 4K 4-OUT, HDMI 2K 8-OUT, OR SDI 12G 4-OUT)
  - **Slot 12** (input HB / high bandwidth)
  - **Slot 11** (input LB / low bandwidth)

### Output cards (Slot 10 only)

```javascript
const OUTPUT_CARDS = {
  'HDMI_4K_4OUT':  { sku: 'C7-PRO-HDMI-4K4OUT', desc: 'HDMI 4K 4-OUT (4 ports @ 3840×2160)', ports: 4, resolution: '4K',  signal: 'HDMI' },
  'HDMI_2K_8OUT':  { sku: 'C7-PRO-HDMI-2K8OUT', desc: 'HDMI 2K 8-OUT (8 ports @ 1920×1080)', ports: 8, resolution: 'FHD', signal: 'HDMI' },
  'SDI_12G_4OUT':  { sku: 'C7-PRO-SDI-12G-4OUT', desc: 'SDI 12G 4-OUT (4 ports @ 4K)',       ports: 4, resolution: '4K',  signal: 'SDI'  }
};
```

### Input cards (8 SKUs, Slot 11 + Slot 12)

```javascript
const INPUT_CARDS = {
  'HDMI_4K_4IN':   { sku: 'C7-PRO-HDMI-4K4IN',   desc: 'HDMI 4K 4-IN (4 ports @ 3840×2160)', ports: 4, resolution: '4K',  signal: 'HDMI',    slots: ['HB'] },
  'HDMI_4K_2IN':   { sku: 'C7-PRO-HDMI-4K2IN',   desc: 'HDMI 4K 2-IN (2 ports @ 3840×2160)', ports: 2, resolution: '4K',  signal: 'HDMI',    slots: ['HB','LB'] },
  'HDMI_2K_4IN':   { sku: 'C7-PRO-HDMI-2K4IN',   desc: 'HDMI 2K 4-IN (4 ports @ 1920×1080)', ports: 4, resolution: 'FHD', signal: 'HDMI',    slots: ['HB','LB'] },
  'HDBASET_2IN':   { sku: 'C7-PRO-HDBT-2IN',     desc: 'HDBaseT 4K 2-IN (2 ports)',          ports: 2, resolution: '4K',  signal: 'HDBaseT', slots: ['HB','LB'] },
  'SDI_12G_4IN':   { sku: 'C7-PRO-SDI-12G-4IN',  desc: 'SDI 12G 4-IN (4 ports @ 4K)',        ports: 4, resolution: '4K',  signal: 'SDI',     slots: ['HB'] },
  'SDI_3G_4IN':    { sku: 'C7-PRO-SDI-3G-4IN',   desc: 'SDI 3G 4-IN (4 ports @ 1080p)',      ports: 4, resolution: 'FHD', signal: 'SDI',     slots: ['HB','LB'] },
  'MEDIA_4K_IN':   { sku: 'C7-PRO-MEDIA-4K-IN',  desc: 'Media 4K Player input',              ports: 1, resolution: '4K',  signal: 'Media',   slots: ['HB','LB'] },
  'AUDIO_2IN_4OUT':{ sku: 'C7-PRO-AUDIO',        desc: 'Audio 2-IN 4-OUT',                   ports: 2, resolution: 'N/A', signal: 'Audio',   slots: ['LB'] }
};
```

`HB` = Slot 12 · `LB` = Slot 11 · `slots` lists which slots a card type can occupy.

### Slot-pairing truth table (locked since v25.80)

**Given Slot 12 (HB) card, what's allowed in Slot 11 (LB)?**

```javascript
const SLOT11_ALLOWED_WHEN_SLOT12 = {
  'empty':         ['HDMI_4K_2IN','HDMI_2K_4IN','HDBASET_2IN','SDI_3G_4IN','MEDIA_4K_IN','AUDIO_2IN_4OUT'],
  'HDMI_2K_4IN':   ['AUDIO_2IN_4OUT'],
  'HDMI_4K_2IN':   ['HDMI_4K_2IN','MEDIA_4K_IN','AUDIO_2IN_4OUT'],
  'HDMI_4K_4IN':   ['HDMI_4K_2IN','HDMI_2K_4IN','HDBASET_2IN','SDI_3G_4IN','MEDIA_4K_IN','AUDIO_2IN_4OUT'],
  'HDBASET_2IN':   ['HDBASET_2IN','HDMI_4K_2IN','MEDIA_4K_IN','AUDIO_2IN_4OUT'],
  'SDI_12G_4IN':   ['HDMI_4K_2IN','HDMI_2K_4IN','HDBASET_2IN','SDI_3G_4IN','MEDIA_4K_IN','AUDIO_2IN_4OUT'],
  'SDI_3G_4IN':    ['AUDIO_2IN_4OUT'],
  'MEDIA_4K_IN':   ['HDMI_4K_2IN','HDBASET_2IN','MEDIA_4K_IN','AUDIO_2IN_4OUT']
  // v25.80 FIX: removed SDI_3G_4IN from MEDIA_4K_IN row per official tvONE configurator
};
```

This table is the **official tvONE CALICO pairing rules**. Any change is a hardware change and must come from tvONE.

---

## 8. Chassis-selection algorithm (verbatim from v25.118 L12215-L12243)

```
INPUT: bd = window._tvInputBreakdownV2580
       hdmiPortsNeeded = sum(displayQty, projectorQty, ledOutputPorts from collectScreens)
       sdiPortsNeeded = bd.sdiOutQty
       userWantsSDI = sdiPortsNeeded > 0
       inputsNeeded = sum of all input counts in bd (hdmi4k+hdmiFhd+sdi12g+sdi3g+hdbt+ip + (audioIn?1:0))

needsInputCardSlots = (bd.sdi12g + bd.sdi3g + bd.hdbt + bd.ip) > 0
audioInChassis = bd.audioIn OR bd.audioNeeded

IF !userWantsSDI AND !needsInputCardSlots AND !audioInChassis
   AND hdmiPortsNeeded <= 2 AND inputsNeeded <= 6:
  chassis = 'C7-PRO-1200'
ELSE:
  chassis = 'C7-PRO-2200'
```

**v25.99.33 lock:** C7-PRO-1200 is ONLY eligible when EVERY input is HDMI (4K or FHD), NO audio, ≤6 inputs, ≤2 HDMI outputs. Any SDI / HDBaseT / IP input → 2U. Any audio → 2U. SDI output → 2U.

---

## 9. Output card selection (after C7-PRO-2200 chosen, Slot 10)

```
nativeHdmi = 4

IF userWantsSDI AND hdmiPortsNeeded > 4:
  ERROR — Slot 10 holds one card; cannot do SDI + extra HDMI. Multi-unit required.

ELSE IF userWantsSDI AND sdiPortsNeeded > 4:
  ERROR — SDI_12G 4-OUT card maxes at 4 ports. Multi-unit required.

ELSE IF !userWantsSDI AND hdmiPortsNeeded > 12:
  ERROR — Single chassis maxes at 12 HDMI (native 4 × 4K + card 8 × FHD). Multi-unit required.

ELSE IF !userWantsSDI AND hdmiPortsNeeded > 8:
  output card = HDMI_2K_8OUT   // 4 native 4K + 8 card FHD = 12 total

ELSE IF !userWantsSDI AND hdmiPortsNeeded > 4 AND hdmiPortsNeeded <= 8:
  output card = HDMI_4K_4OUT   // 4 native + 4 card = 8 × 4K

ELSE IF userWantsSDI AND sdiPortsNeeded > 0 AND sdiPortsNeeded <= 4:
  output card = SDI_12G_4OUT   // 4 × 4K SDI; native HDMI usable

ELSE (HDMI ≤ 4, no SDI):
  no output card (chassis native sufficient)
```

---

## 10. Input card algorithm — `pickInputCards()` (verbatim from v25.118 L12035-L12185)

```
INPUT: bd, extraInputsNeeded = max(0, totalInputs - 8)

// v25.100.1 guard — don't bail early if non-HDMI inputs exist
nonHdmiInputs = bd.sdi12g + bd.sdi3g + bd.hdbt + bd.ip
IF extraInputsNeeded <= 0 AND nonHdmiInputs == 0 AND !bd.audioNeeded:
  return []

cardsNeeded = []

// Step 1 — HDMI overflow → 4K cards (native handles up to 8 HDMI free)
hdmiTotal = bd.hdmi4k + bd.hdmiFhd
hdmiOverflow = max(0, hdmiTotal - 8)
IF hdmiOverflow >= 4:
  cardsNeeded.push(HDMI_4K_4IN); hdmiOverflow -= 4
WHILE hdmiOverflow > 0:
  cardsNeeded.push(HDMI_4K_2IN); hdmiOverflow -= 2

// Step 2 — SDI 12G → SDI_12G_4IN (HB-only)
WHILE bd.sdi12g > 0:
  cardsNeeded.push(SDI_12G_4IN); bd.sdi12g -= 4

// Step 3 — SDI 3G → SDI_3G_4IN
WHILE bd.sdi3g > 0:
  cardsNeeded.push(SDI_3G_4IN); bd.sdi3g -= 4

// Step 4 — HDBaseT → HDBASET_2IN
WHILE bd.hdbt > 0:
  cardsNeeded.push(HDBASET_2IN); bd.hdbt -= 2

// Step 5 — IP → MEDIA_4K_IN (1 port each)
WHILE bd.ip > 0:
  cardsNeeded.push(MEDIA_4K_IN); bd.ip -= 1

// Step 6 — Audio → AUDIO_2IN_4OUT (LB-only)
IF bd.audioNeeded:
  cardsNeeded.push(AUDIO_2IN_4OUT, lbOnly: true)

// Step 7 — Pack into 2 slots (Slot 12 HB, Slot 11 LB)
// Greedy: HB-only first, LB-only next, flexible last with pairing-rule check
slot12Key = null; slot11Key = null
FOR card IN cardsNeeded WHERE hbOnly: place in slot12; break
FOR card IN cardsNeeded WHERE lbOnly: place in slot11; break
FOR each remaining card:
  IF !slot12Key: place in slot12
  ELIF !slot11Key:
    IF card.key in SLOT11_ALLOWED_WHEN_SLOT12[slot12Key]: place in slot11
    ELSE: mark unfittable

picks = []
IF slot12Key: picks.push({card: INPUT_CARDS[slot12Key], qty: 1, slot: 'HB (Slot 12)'})
IF slot11Key: picks.push({card: INPUT_CARDS[slot11Key], qty: 1, slot: 'LB (Slot 11)'})

IF any unfittable:
  concerns.push("NOT POSSIBLE in single chassis — slot constraints prevent fit")
```

---

## 11. Defensive assertions (locked from v25.x debugging history)

1. **v25.99.37 INPUT CARD MISSING** — if breakdown has non-HDMI inputs but no input card landed in BoM, surface a concern (catches engine bugs early).
2. **v25.100.1 stale-breakdown guard** — `_recomputeBreakdown()` MUST be called at the top of `_calculateAndLogImpl` before reading any field. Don't trust `oninput` to have fired.
3. **`inputsNeeded > 16`** — single-chassis max. Anything above → multi-unit concern.
4. **C7-PRO-1200 eligibility (v25.99.33)** — NEVER pick 1U for non-HDMI inputs, regardless of input count.

---

## 12. Save flow + edit-restore

### Save (write side)

`_calicoCalculateAndLog()` builds:
1. `header` payload — submission shape (refId, dealValue, salesPerson, projectContext, etc.)
2. `lines[]` from BoM — `{ product_family: 'CALICO', sku, qty, line_total_inr (0 — CALICO has no prices), notes }`
3. `raw_submission` blob (via `_sbEnrichBlob`) — includes `_inputSignals` (per-signal exact counts), `_screens` (with pitch), `_outputBreakdown`

`_sbDealSave({ header, lines, raw })` writes atomically. Status = `'viewed'` (NOT `'pending'` — Postgres rejects per v25.108.3).

LED screens write to `deal_screens` table separately (one row per screen).

### Edit-restore (read side)

`startEditingSubmission()` for CALICO branch:
1. Select VP family pill + CALICO sub-pill, fire onChange
2. Read `raw_submission._inputSignals` → populate Card 02 7 fields directly (lossless)
3. Read `raw_submission._screens` + DB `deal_screens` rows → rebuild LED detail block (width, height, pitch)
4. Read `raw_submission._outputBreakdown` → populate Card 03 5 rows
5. Read `raw_submission._sxCarts` (if present) → repopulate 4 SX window carts
6. Call `_recomputeBreakdown()` once at end to rebuild `_tvInputBreakdownV2580`

Pre-v25.101.4 deals lack `_inputSignals` blob → fall back to lossy guess (existing behavior, no regression).

---

## 13. Acceptance tests

| # | Test | Expected |
|---|---|---|
| 1 | All-HDMI small config — HDMI 4K=2 + HDMI FHD=2 + Display=2 (4K) | C7-PRO-1200 chassis, NO cards (fits 1U native) |
| 2 | All-HDMI medium — HDMI 4K=4 + HDMI FHD=4 + Display=4 (4K) | C7-PRO-2200, NO input cards (8 native), NO output card |
| 3 | All-HDMI overflow — HDMI 4K=6 + HDMI FHD=4 + Display=4 | C7-PRO-2200 + HDMI_4K_2IN (input) for HDMI overflow + NO output card |
| 4 | SDI 12G input only — SDI 12G=4 + Display=2 (4K) | C7-PRO-2200 + SDI_12G_4IN in HB + NO output card |
| 5 | SDI 3G + HDBaseT — SDI 3G=4 + HDBaseT=2 + Display=4 | C7-PRO-2200 + SDI_3G_4IN HB + HDBASET_2IN LB (pairing-rule check) + NO output card |
| 6 | SDI output — HDMI 4K=2 + SDI Out=4 + Display=2 | C7-PRO-2200 + SDI_12G_4OUT in Slot 10 |
| 7 | Many HDMI outputs — HDMI 4K=4 + Display=6 (4K) | C7-PRO-2200 + HDMI_4K_4OUT card (4 native + 4 card = 8 × 4K) |
| 8 | Even more HDMI outputs — HDMI 4K=4 + Display=10 | C7-PRO-2200 + HDMI_2K_8OUT card (4 × 4K native + 8 × FHD card = 12 total) |
| 9 | Audio in + out — HDMI 4K=2 + Audio In=Yes + Audio Out=Yes | C7-PRO-2200 + AUDIO_2IN_4OUT in LB Slot 11 |
| 10 | Forbidden combo — SDI Out=4 + HDMI Display=6 | ERROR — Slot 10 cannot serve both SDI + HDMI expansion |
| 11 | LED screen ports — LED Screens=1, screen: 7680×2160 px | LED ports = ceil(16.6M / 8.29M) = 2 ports |
| 12 | Multi-screen LED port math — 2 screens at 5120×1440 each | LED ports = ceil(7.37M/8.29M) + ceil(7.37M/8.29M) = 1 + 1 = 2 (NOT ceil(14.7M/8.29M) = 2 either way, but the per-screen ceil rule is the locked behavior) |
| 13 | Edit-restore CALICO deal — save HDMI 4K=2 + SDI 3G=2 + LED Screens=1 + screens detail. Refresh. Edit. | Form populates exactly: 2 HDMI 4K, 2 SDI 3G, LED qty 1, screen 1 width/height/pitch restored |
| 14 | INPUT CARD MISSING defensive — manually patch breakdown to have SDI but no card | engine surfaces "⚠ INPUT CARD MISSING" concern |
| 15 | SX panel — pick SX Yes at bottom of Card 03 | SX panel expands below; user can add HDBT/Splitter/AOC/AP-536 items |

---

## 14. Out of scope for v26.5.0

- CORIO wizard (v26.7.0)
- MV wizard (v26.4.0 — already specified)
- SX panel implementation (v26.6.0 — Yes/No pill wired in v26.6, not v26.5)
- Multi-chassis recommendations (always single-chassis in this engine — multi-chassis surfaces as a concern only)
- Customer directory (B2 — pending party registry data)

---

## 15. What v26.5.0 ship looks like

1. Add `calicoWizardCard` (Card 02 + Card 03 markup per §3, §4)
2. Insert LED screens detail block markup + `addScreen()` / `removeLastScreen()` / `updateReadout()` JS (verbatim from v25.118 L11871-L11942)
3. Insert catalog constants (`CHASSIS`, `INPUT_CARDS`, `OUTPUT_CARDS`, `SLOT11_ALLOWED_WHEN_SLOT12`, `PORT_CAPACITY_4K60`) verbatim from v25.118 §7 of this doc
4. Insert `_recomputeBreakdown()` — reads 7 input fields + 5 output fields, populates `_tvInputBreakdownV2580`
5. Insert `recommend()` engine — chassis cascade §8 + output card selection §9 + `pickInputCards()` §10 + defensive assertions §11
6. Insert `_calicoCalculateAndLog()` save flow §12
7. Insert CALICO branch in `startEditingSubmission()` for edit-restore §12
8. Wire SX Yes/No pill at bottom of Card 03 (panel itself is v26.6 scope)
9. Bump version `26.4.x` → `26.5.0` with inline changelog
10. `node --check` validation
11. Deliver `index.html` to `/mnt/user-data/outputs/`

**Estimated effort: ~1500 lines net add. No DB schema change (raw_submission jsonb absorbs everything new). No backend change.**

---

*End of CALICO-SPEC-v26.5.0. Source: voice clarification with Dipenkumar 2026-05-22 + extraction from v25.118.0 git commit 2ba47bb.*
