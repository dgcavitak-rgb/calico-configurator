# SX v26.6.0 → v26.3.0 file integration delta

**Reconciles SX-SPEC-v26.6.0 against the actual v26.3.0 file state. Spec's gap analysis assumed less in-place; reality is partial wiring exists. This doc maps exact edits.**

---

## 0. File-reality reconciliation

### Already in v26.3.0 (don't re-add)

| Item | Location |
|---|---|
| All 5 SX catalogs (HDBT_MAP, DA_MAP, AP_MAP, AOC_CODE, AOC_AVAIL) | L7617-L7647 ✓ |
| `_sxCollectAllLines()` call sites with `typeof === 'function'` guards | 7 places (L4237, L9618, L10046, L10269, L11266, L11360, L11460) ✓ |
| `_sbEnrichBlob` saves all 4 carts to `raw_submission._sxCarts` | L8053-L8116 ✓ |
| Edit-restore: blob-first + project_lines fallback + auto-open + render dispatch | L10920-L10994 ✓ |
| Reset clear of all 4 carts + render dispatch | L4633-L4640 ✓ |
| `sxWizardCard` + `sxBody` placeholder markup | L16870-L16881 ✓ |
| Visibility model: `.wizard-card { display:none } .wizard-card.active { display:block }` | L16684 ✓ |
| Progressive-disclosure sxCard show on isMv/isCalico/isCorio | L9847-L9848 ✓ (but uses wrong ID — see fix #11) |

### Not yet in v26.3.0 (this delta adds)

| Item | Why |
|---|---|
| Module-top cart global declarations | Currently created inline only during edit-restore |
| 4 sub-wizard UI markup blocks inside `sxBody` | Placeholder paragraph at L16876-L16879 must be replaced |
| 12 functions: `_sxHdbtAdd/Remove/Render`, `_sxDaAdd/Remove/Render`, `_sxAocAdd/Remove/Render`, `_sxApAdd/Remove/Render` | Defined nowhere |
| `_sxCollectAllLines()` body | Only call sites exist |
| `_sxRebuildSummary()` body | Only call site exists |
| `_onSxToggle()` body | New |
| `_sxAocFilterLengths()` helper | New — drives AOC length dropdown |
| CSS for sub-wizards + trigger pills | New |
| MV trigger pill markup | Spec §3, none in file |
| CORIO trigger pill markup | Spec §3, none in file |
| Version bump 26.3.0 → 26.6.0 + inline changelog | Standard discipline |

### Decisions locked

| Decision | Choice |
|---|---|
| Panel ID | Keep existing `#sxWizardCard` + `#sxBody`. Don't rename to spec's `#sxPanel` — 5 existing JS callsites reference `#sxWizardCard`. |
| CALICO trigger pill | **Deferred to v26.5.0** (calicoWizardCard doesn't exist yet in v26.3.0). `_onSxToggle()` uses `querySelectorAll` which is robust to 0 matches. |
| Stale `#signalExtensionCard` refs at L9847 + L10988 | **Repoint to `#sxWizardCard`** — latent bug, fixed alongside this work. |
| `sx-panel` CSS class on `sxWizardCard` | Not added — existing `.wizard-card` class is sufficient. Sub-wizard CSS uses `.sx-subwiz` namespace below it. |
| Auto-open after edit-restore | Existing logic at L10987-L10994 toggles `data-sx-open` + `sxBody.style.display=''`. **Replace with `_onSxToggle('yes')` call** for consistency. |

---

## 1. Edit map — 12 surgical edits

### Edit 1 — Version bump (L2453)
`const TVONE_FRONTEND_VERSION = '26.3.0';` → `'26.6.0';` + add inline changelog block above

### Edit 2 — Add cart globals + 14 functions (after L7647)
Single ~600-line insertion immediately after `SX_AOC_AVAIL` catalog closes (L7647), before `CORIO_CHASSIS` (L7650).

Contains:
- 4 cart globals (`window._sxHdbtCart ??= []`, etc.) — idempotent so edit-restore doesn't blow them away
- `_sxCollectAllLines()`
- `_sxRebuildSummary()`
- `_onSxToggle()`
- `_sxAocFilterLengths()` helper
- `_sxHdbtAdd / Remove / Render`
- `_sxDaAdd / Remove / Render`
- `_sxAocAdd / Remove / Render`
- `_sxApAdd / Remove / Render`
- All exposed on `window` so the existing call sites + edit-restore guards resolve

### Edit 3 — Replace sxBody placeholder with 4 sub-wizard markup (L16875-L16880)
Replace the single "Engine populates extender selections here…" paragraph with the 4 sub-wizard cards + summary footer.

### Edit 4 — MV trigger pill (after L16860, before L16862 closing of mv_outputSignal field)
Insert `<div class="mv-ext-question">` block per SX spec §3.

### Edit 5 — CORIO trigger pill (after L16842, before L16843 closing of corioWizardCard)
Insert `<div class="corio-ext-question">` block per SX spec §3.

### Edit 6 — CSS additions
Append to existing `<style>` block — `.sx-subwiz`, `.sx-subwiz-head`, `.sx-subwiz-body`, `.sx-cart`, `.sx-cart-row`, `.sx-cart-remove`, `.sx-summary`, `.mv-ext-question`, `.corio-ext-question`, `.pill-group`, `.mv-ext-pill`, `.corio-ext-pill`, `.sx-stepper`, `.sx-add-btn`.

### Edit 7 — Fix stale `signalExtensionCard` → `sxWizardCard` at L9847
1 word repoint.

### Edit 8 — Fix stale `signalExtensionCard` → `sxWizardCard` at L10988 + replace manual auto-open with `_onSxToggle('yes')` call
Aligns edit-restore auto-open with the unified trigger handler.

### Edit 9 — Wire reset to set trigger pills to "No" via `_onSxToggle('no')` (after L4640)
Existing reset clears carts + renders panels. Add `_onSxToggle('no')` after render dispatch so trigger pills sync.

### Edit 10 — Validate via `node --check` (Python extract → temp .js)
Per ops principles: extract inline `<script>` blocks → temp `.js` → `node --check`.

### Edit 11 — Deliver modified `index.html` to `/mnt/user-data/outputs/`

### Edit 12 — Acceptance test exit criteria
- Click MV "Yes" → sxWizardCard appears with all 4 sub-wizards populated
- Click CORIO "Yes" → same panel appears (synced)
- HDBaseT Tx=3, Rx=3, Signal=Video+Audio → Add → 1 cart line `2211079-03 × 3` HD-One DX Kit
- HDBaseT asymmetric Tx=2, Rx=4 → Add → 2 lines (tx-sku × 2 + rx-sku × 4)
- Splitter MG-DA-614 × 2 Add → MG-DA-614 × 1 Add → 1 line `MG-DA-614 × 3` (qty merged)
- AOC HDMI Std → length dropdown shows [10,15,20,25,30,40,50,60,70,100]
- AOC HDMI Armored → length dropdown shows [10,30,100]
- AP-536 × 2 Add → AP-536 × 1 Add → merged `AP-536 × 3`
- Save MV deal with HDBT extender → reopen → cart restores from blob + panel auto-opens
- Reset → all 4 carts empty, trigger pills set to No, panel collapses

---

## 2. Out of scope (this session)

- CALICO trigger pill — v26.5.0 will add when calicoWizardCard ships
- HDBaseT 500-series (152m FHD) — Phase B per spec §12
- Fiber MG-FB-* — Phase B
- Encoder-100 — Phase B
- AOC custom lengths — only catalog lengths supported per spec §12
- BoM/Excel quote rendering of SX lines — existing `_sxCollectAllLines()` consumers handle this via the existing call sites; no Excel changes needed

---

*End of integration delta. Executing now.*
