# MV Rebuild Spec — v26.4.0 (REVISED)

**Generated 2026-05-22. SUPERSEDES the prior `MV-SPEC-v26.4.0.md` from 2026-05-21. Locks in 5 changes from voice clarification with Dipenkumar 2026-05-22: (1) `MWP-4Hi-1Y` added as 7th fixed chassis (mixed HDMI FHD + AVIP), (2) AVIP becomes a 7th MV input signal, (3) HDMI 1080p MV output DROPPED, (4) SDI 3G now has dual card-size options, (5) explicit fixed-first preference rule across single AND mixed-input matching.**

---

## 1. What's changed from the 2026-05-21 spec

| Change | Old | New |
|---|---|---|
| Fixed chassis count | 5 (MWP-4D, 4H, 4Y, 8GS, 8H) | **7** (added `MWP-4Hi-1Y` + `MWP-MTO` was already separate) |
| MV input signals | 6 (DVI-U, FHD HDMI, 4K HDMI, 3G-SDI, HD-SDI, HDBaseT) | **7** (added `AVIP`) |
| MV output signals | 5 (4K HDMI, HDMI 1080p, DVI-I, 3G SDI, HDBaseT) | **4** (`HDMI 1080p` REMOVED — not available on any fixed chassis OR MTO) |
| SDI 3G input card | `CV-3GSDI-4IN-FF` only (4-port) | **Two options**: `CV-3GSDI-2IN-FF` (2-port) + `CV-3GSDI-4IN-FF` (4-port). Prefer min required, escalate when qty ≥ 3. |
| Mixed-input fixed chassis | None (mixed always → MTO) | **`MWP-4Hi-1Y`** handles HDMI FHD + AVIP mixed in a single fixed chassis. MTO is fallback only. |
| AVIP MTO card | Not in catalog | `CV-AVIP-IN-1USB-1ETH-128-FF` (128 GB default, per Dipenkumar 2026-05-22) |

---

## 2. CORIOview product catalog (locked 2026-05-22)

### Fixed-chassis SKUs (6 fixed + 1 MTO = 7 total)

```javascript
const CORIOVIEW_CHASSIS = [
  // Single-signal fixed chassis
  { sku: 'MWP-4D-1Y',  inSignal: 'DVI-U',    inPorts: 4, outSignal: '4K HDMI', desc: 'CORIOview MWP-4D-1Y · 4× DVI-U in / 1× 4K HDMI out',           mixed: false },
  { sku: 'MWP-4H-1Y',  inSignal: 'FHD HDMI', inPorts: 4, outSignal: '4K HDMI', desc: 'CORIOview MWP-4H-1Y · 4× FHD HDMI in / 1× 4K HDMI out',        mixed: false },
  { sku: 'MWP-4Y-1Y',  inSignal: '4K HDMI',  inPorts: 4, outSignal: '4K HDMI', desc: 'CORIOview MWP-4Y-1Y · 4× 4K HDMI in / 1× 4K HDMI out',         mixed: false },
  { sku: 'MWP-8GS-1Y', inSignal: '3G-SDI',   inPorts: 8, outSignal: '4K HDMI', desc: 'CORIOview MWP-8GS-1Y · 8× 3G-SDI in / 1× 4K HDMI out',         mixed: false },
  { sku: 'MWP-8H-1Y',  inSignal: 'FHD HDMI', inPorts: 8, outSignal: '4K HDMI', desc: 'CORIOview MWP-8H-1Y · 8× FHD HDMI in / 1× 4K HDMI out',        mixed: false },
  // Mixed-input fixed chassis (NEW in v26.4)
  { sku: 'MWP-4Hi-1Y', inSignals: ['FHD HDMI', 'AVIP'], inPortsFhd: 4, inPortsAvip: 2, outSignal: '4K HDMI',
    desc: 'CORIOview MWP-4Hi-1Y · 4× FHD HDMI + 2× AVIP streams (1 card) / 1× 4K HDMI out', mixed: true }
];

// MTO chassis (single OR mixed input/output via factory-fitted cards)
const MWP_MTO = {
  sku: 'MWP-MTO',
  desc: 'CORIOview MWP-MTO chassis (Made-to-Order)',
  maxInputCards: 2,
  maxOutputCards: 1
};
```

### MV input signal types (7 total — AVIP is new)

```javascript
const MV_INPUT_SIGNALS = ['DVI-U', 'FHD HDMI', '4K HDMI', '3G-SDI', 'HD-SDI', 'HDBaseT', 'AVIP'];
```

### MTO input-card SKUs (per signal type — verbatim from Dipenkumar 2026-05-22)

```javascript
const CORIOVIEW_INPUT_CARDS = {
  'DVI-U':    [
    { sku: 'CV-DVIU-2IN-FF', portsPerCard: 2, desc: 'CORIOview Input module: Dual 2× DVI-U via DVI-I (Factory Fit)' }
  ],
  'FHD HDMI': [
    { sku: 'CV-HDMI-4IN-FF', portsPerCard: 4, desc: 'CORIOview HDMI 1080p 4-IN (Factory Fit)' }
  ],
  '4K HDMI':  [
    { sku: 'CV-HDMI-4K-2IN-FF', portsPerCard: 2, desc: 'CORIOview HDMI 4K 2-IN (Factory Fit)' }
  ],
  '3G-SDI':   [
    { sku: 'CV-3GSDI-2IN-FF', portsPerCard: 2, desc: 'CORIOview 3G SDI 2-IN (Factory Fit)' },
    { sku: 'CV-3GSDI-4IN-FF', portsPerCard: 4, desc: 'CORIOview 3G SDI 4-IN (Factory Fitted)' }
  ],
  'HD-SDI':   [
    { sku: 'CV-HDSDI-4IN-FF', portsPerCard: 4, desc: 'CORIOview Input Module 4× HD/SD-SDI via BNC (Factory Fit)' }
  ],
  'HDBaseT':  [
    { sku: 'CV-HDBT-2IN-1ETH-FF', portsPerCard: 2, desc: 'CORIOview module HDBT 2-IN + Ethernet (Factory Fit)' }
  ],
  'AVIP':     [
    { sku: 'CV-AVIP-IN-1USB-1ETH-128-FF', portsPerCard: 2, desc: 'CORIOview 4K Media Streaming Input 128 GB SSD (Factory Fit)', default: true },
    { sku: 'CV-AVIP-IN-1USB-1ETH-FF',     portsPerCard: 2, desc: 'CORIOview 4K Media Streaming Input 16 GB SSD (Factory Fit)',  default: false }
  ]
};
```

### MTO output-card SKUs (per output signal — `HDMI 1080p` DROPPED)

```javascript
const CORIOVIEW_OUTPUT_CARDS = {
  '4K HDMI': { sku: 'CV-HDMI-4K-SC-1OUT-FF',   desc: 'CORIOview HDMI 4K Single Scaled Output (Factory Fit)' },
  'DVI-I':   { sku: 'CV-DVI-I-SC-2OUT-FF',     desc: 'CORIOview Output Module Single Scaled Output (Factory Fit)' },
  '3G SDI':  { sku: 'CV-3GSDI-SC-2OUT-FF',     desc: 'CORIOview 3G SDI Single Scaled Output (Factory Fit)' },
  'HDBaseT': { sku: 'CV-HDBT-SC-2OUT-1ETH-FF', desc: 'CORIOview HDBaseT Single Scaled Output (Factory Fit)' }
};

// Note: `HDMI 1080p` output is REMOVED. No fixed chassis outputs FHD HDMI (all 6 output 1× 4K HDMI),
// and MTO has no FHD HDMI output card available. Output dropdown shows 4 options only.
```

### Per-signal qty caps (per row in MV input UI)

```javascript
const MV_QTY_CAP = {
  'DVI-U':    4,  // 2-port card × max 2 MTO slots = 4
  'FHD HDMI': 8,  // 4-port card × max 2 MTO slots = 8
  '4K HDMI':  4,  // 2-port card × max 2 MTO slots = 4
  '3G-SDI':   8,  // 4-port card × max 2 MTO slots = 8 (using 4-port variant)
  'HD-SDI':   8,  // 4-port card × max 2 MTO slots = 8
  'HDBaseT':  4,  // 2-port card × max 2 MTO slots = 4
  'AVIP':     4   // 2-port card × max 2 MTO slots = 4 (NEW)
};
```

---

## 3. Decision algorithm — `recommendMWP(inputs, outputSignal)` (REVISED)

**Hierarchy:** Try fixed-chassis FIRST in this order, fall through to MTO only when no fixed fits.

```
INPUT: validInputs = inputs.filter(r => r.signal && r.qty > 0)
       outputSignal ∈ {'4K HDMI', 'DVI-I', '3G SDI', 'HDBaseT'}

IF validInputs.length == 0 OR !outputSignal:
  return { type: 'empty' }

// =================================================================
// STEP 1 — Single-signal fixed-chassis match (output must be 4K HDMI)
// =================================================================
IF validInputs.length == 1 AND outputSignal == '4K HDMI':
  { signal, qty } = validInputs[0]
  candidates = CORIOVIEW_CHASSIS.filter(c =>
    !c.mixed AND c.inSignal == signal AND c.inPorts >= qty
  )
  IF candidates.length > 0:
    sort candidates by inPorts ASC
    chosen = candidates[0]  // smallest that fits
    return {
      type: 'fixed',
      chassis: chosen,
      bom: [{ family: 'CORIOVIEW', category: 'chassis', sku: chosen.sku, qty: 1,
              description: chosen.desc, inputSignal: signal, outputSignal: outputSignal,
              inputCount: qty }]
    }

// =================================================================
// STEP 2 — Mixed-input fixed-chassis match: MWP-4Hi-1Y (NEW in v26.4)
// =================================================================
// MWP-4Hi-1Y handles 4× FHD HDMI + up to 2× AVIP streams with 4K HDMI output.
// Trigger: HDMI FHD + AVIP only, no other signal types, qtys within caps.

IF outputSignal == '4K HDMI':
  fhdQty  = sum of validInputs where signal == 'FHD HDMI'
  avipQty = sum of validInputs where signal == 'AVIP'
  otherQty = sum of validInputs where signal NOT IN {'FHD HDMI', 'AVIP'}

  IF fhdQty > 0 AND avipQty > 0 AND otherQty == 0
     AND fhdQty <= 4 AND avipQty <= 2:
    chassis = MWP-4Hi-1Y
    return {
      type: 'fixed-mixed',
      chassis: chassis,
      bom: [{ family: 'CORIOVIEW', category: 'chassis', sku: 'MWP-4Hi-1Y', qty: 1,
              description: chassis.desc, inputSignal: 'FHD HDMI + AVIP', outputSignal: '4K HDMI',
              inputCount: fhdQty + avipQty }]
    }

// =================================================================
// STEP 3 — MTO fallback (single-signal OR mixed-input)
// =================================================================
// Reached when:
//   (a) Output ≠ 4K HDMI (no fixed chassis supports non-4K-HDMI output), OR
//   (b) Signal not in single-signal fixed catalog (e.g. HD-SDI alone, AVIP alone), OR
//   (c) Mixed inputs that don't match MWP-4Hi-1Y's exact pattern

outputCard = CORIOVIEW_OUTPUT_CARDS[outputSignal]
IF !outputCard:
  return { type: 'error', error: `Output signal "${outputSignal}" not supported.` }

cardLines = []
totalCards = 0

FOR each row IN validInputs:
  { signal, qty } = row
  cardOptions = CORIOVIEW_INPUT_CARDS[signal]
  IF !cardOptions:
    return { type: 'error', error: `Input signal "${signal}" not supported.` }

  // Pick smallest card that fits, escalate when needed (prefer-min rule)
  chosenCardOption = pickMinCard(cardOptions, qty)
  cardsNeeded = ceil(qty / chosenCardOption.portsPerCard)
  cardLines.push({
    family: 'CORIOVIEW', category: 'card',
    sku: chosenCardOption.sku, qty: cardsNeeded,
    description: chosenCardOption.desc, inputSignal: signal
  })
  totalCards += cardsNeeded

IF totalCards > MWP_MTO.maxInputCards:
  return {
    type: 'error',
    error: `This configuration needs ${totalCards} input cards but MWP-MTO supports max ${MWP_MTO.maxInputCards}. Contact tvONE for a custom build.`
  }

return {
  type: 'mto',
  chassis: { sku: MWP_MTO.sku, desc: MWP_MTO.desc },
  bom: [
    { family: 'CORIOVIEW', category: 'chassis', sku: MWP_MTO.sku, qty: 1,
      description: MWP_MTO.desc, outputSignal: outputSignal },
    ...cardLines,
    { family: 'CORIOVIEW', category: 'card', sku: outputCard.sku, qty: 1,
      description: outputCard.desc, outputSignal: outputSignal }
  ]
}
```

### `pickMinCard(cardOptions, qty)` helper (NEW in v26.4)

```javascript
function pickMinCard(cardOptions, qty) {
  // Prefer min required. Escalate to higher-port card only when needed.
  // For signals with single card option, returns that card.
  // For signals with multiple options (3G-SDI, AVIP), picks smallest sufficient.
  if (cardOptions.length === 1) return cardOptions[0];

  // Sort by portsPerCard ASC (smallest first)
  const sorted = cardOptions.slice().sort((a, b) => a.portsPerCard - b.portsPerCard);

  // For 3G-SDI: 2-port for qty 1-2, 4-port for qty >= 3 (rule per Dipenkumar 2026-05-22)
  // For AVIP: only default-tagged card is the 128 GB variant; 16 GB is alternative
  const defaultCard = sorted.find(c => c.default === true);
  if (defaultCard) return defaultCard;

  // Generic min-card rule: smallest card whose portsPerCard >= qty (single card),
  // else escalate to next-larger
  for (const card of sorted) {
    if (card.portsPerCard >= qty) return card;
  }
  // No single card fits — return largest (multi-card pack will handle)
  return sorted[sorted.length - 1];
}
```

---

## 4. UI behavior (port from v25.118 L13373-L13502)

### Input-rows state

```javascript
window._mvInputRows = [{ signal: '', qty: 1 }];  // 1..2 entries
```

### Dynamic row table inside `mvWizardCard`

For each row in `_mvInputRows`:
- **Signal type select** — options from `MV_INPUT_SIGNALS` (7 options incl. AVIP). Exclude signals already picked in OTHER rows (mutually exclusive across rows).
- **Qty number input** — `min=1`, `max=MV_QTY_CAP[signal]`, clamp on change. For AVIP: max=4.
- **Remove button** — hidden when only 1 row, fires `_mvRemoveInputRow(idx)`

### "+ Add another input signal type" button

- Visible always
- `disabled = (_mvInputRows.length >= MWP_MTO.maxInputCards)` (disabled at 2 rows for MTO compatibility)
- Tooltip when disabled: "Max 2 signal types in current MTO spec — contact tvONE for higher-density custom builds"
- Fires `_mvAddInputRow()` → appends `{ signal: '', qty: 1 }`

### Output signal select (REVISED — 4 options only)

```html
<select class="field-select" id="mv_outputSignal" onchange="_mvRecompute()">
  <option value="4K HDMI">4K HDMI</option>
  <option value="DVI-I">DVI-I</option>
  <option value="3G SDI">3G SDI</option>
  <option value="HDBaseT">HDBaseT</option>
</select>
```

(HDMI 1080p removed — see §1.)

### Preview tag wording

After every change → `recommendMWP(_mvInputRows, outputSignal)`:
- `type === 'empty'` → show "Fill inputs to see recommendation"
- `type === 'fixed'` → show chassis SKU + tag "Fixed chassis"
- `type === 'fixed-mixed'` → show "MWP-4Hi-1Y" + tag "Fixed mixed-input chassis"
- `type === 'mto'` → show "MWP-MTO build" + tag "MTO build" (or "MTO build · mixed input" if multiple signals)
- `type === 'error'` → show red error from `result.error`

### Empty-state guard

The preview block must HIDE when `result.type === 'empty'`. Do not render chassis with placeholder text. Confirmed already correct in v26.3.1 (`_mvRecompute` already does this).

---

## 5. mvWizardCard HTML (REVISED)

Replace entire content of `mvWizardCard` (currently at v26.3.1 L16869) with:

```html
<div class="wizard-card" id="mvWizardCard">
  <div class="wizard-head">
    <h3>Multi Viewer configuration</h3>
    <span class="wizard-tag" id="mvPreviewTag">—</span>
  </div>

  <div class="field">
    <p class="field-label-strong">Input signals</p>
    <p class="field-hint">Pick one signal type for a fixed chassis. Add a second for mixed-input builds (max 2 types). MWP-4Hi-1Y supports FHD HDMI + AVIP as a fixed chassis; other mixed-input combos route to MWP-MTO.</p>
    <table class="mv-input-table" id="mvInputTable">
      <thead>
        <tr><th>Signal type</th><th>Quantity</th><th></th></tr>
      </thead>
      <tbody id="mvInputTableBody">
        <!-- _mvRenderInputRows() populates -->
      </tbody>
    </table>
    <button type="button" class="btn-secondary" id="mvAddInputBtn" onclick="_mvAddInputRow()">+ Add another input signal type</button>
  </div>

  <div class="field">
    <label class="field-label" for="mv_outputSignal">Output signal</label>
    <select class="field-select" id="mv_outputSignal" onchange="_mvRecompute()">
      <option value="4K HDMI">4K HDMI</option>
      <option value="DVI-I">DVI-I</option>
      <option value="3G SDI">3G SDI</option>
      <option value="HDBaseT">HDBaseT</option>
    </select>
    <p class="field-hint">Non-4K-HDMI outputs route to MWP-MTO. Mixed inputs match MWP-4Hi-1Y when FHD HDMI + AVIP only; otherwise MWP-MTO.</p>
  </div>

  <div class="wizard-preview" id="mvPreview" style="display:none">
    <p class="wizard-preview-tag">RECOMMENDED MV</p>
    <div class="wizard-preview-chassis" id="mvPreviewChassis">—</div>
    <div class="wizard-preview-bom" id="mvPreviewBom">Fill inputs to see recommendation.</div>
  </div>
</div>
```

---

## 6. Functions to port from v25.118

Read from `v25.118.0.html` at these exact line ranges:

| Function | v25.118 lines | Purpose | Changes for v26.4 |
|---|---|---|---|
| `CORIOVIEW_CHASSIS` | L13013-L13045 | Catalog constants | Add MWP-4Hi-1Y row, update mixed-input fields |
| `CORIOVIEW_INPUT_CARDS` | L13022 | Input card catalog | Add AVIP entry, add 2-port SDI 3G option |
| `CORIOVIEW_OUTPUT_CARDS` | L13022 | Output card catalog | Remove HDMI 1080p entry |
| `MWP_MTO` | L13045 | MTO constants | Unchanged |
| `MV_QTY_CAP` | L13045 | Per-signal caps | Add AVIP: 4 |
| `recommendMWP()` | L13054-L13152 | Decision engine | Add STEP 2 mixed-input fixed match for MWP-4Hi-1Y; add `pickMinCard` helper for 3G-SDI/AVIP card-size selection |
| `_mvRenderInputRows()` | L13373-L13420 | Renders row table | Add AVIP to signal options |
| `_mvOnSignalChange(idx, newSignal)` | L13437-L13447 | Mutates row signal, clamps qty | Honor new MV_QTY_CAP['AVIP'] = 4 |
| `_mvOnQtyChange(idx, newQty)` | L13449-L13455 | Mutates row qty | Unchanged |
| `_mvAddInputRow()` | L13458-L13463 | Appends a row | Unchanged |
| `_mvRemoveInputRow(idx)` | L13479-L13486 | Splices a row | Unchanged |
| `_mvRecompute()` | locate via grep ~L13500-L13525 | Updates preview UI | Handle new `type:'fixed-mixed'` result type |

### Engine save flow

`_mvCalculateAndLog` at v26.3.1 L8101 reads from `window._mvInputRows` — no change needed. Once `_mvInputRows` carries AVIP rows, the save flow takes over.

`_sbEnrichBlob` already stashes `_mvRows = { inputRows, outputSignal }` at save (v25.108.1 lossless path). Unchanged.

---

## 7. Acceptance tests (REVISED — adds 4 new)

| # | Test | Expected |
|---|---|---|
| 1 | Fixed chassis, single input — pick "4K HDMI" qty 4 + output "4K HDMI" | recommends MWP-4Y-1Y |
| 2 | Fixed chassis, smaller qty — pick "FHD HDMI" qty 3 + output "4K HDMI" | recommends MWP-4H-1Y (smallest fit) |
| 3 | MTO single-signal because output ≠ 4K HDMI — "FHD HDMI" qty 4 + output "3G SDI" | recommends MWP-MTO + CV-HDMI-4IN-FF + CV-3GSDI-SC-2OUT-FF |
| 4 | MTO mixed inputs — "4K HDMI" qty 2 + "3G-SDI" qty 4 + output "4K HDMI" | recommends MWP-MTO + CV-HDMI-4K-2IN-FF + CV-3GSDI-4IN-FF + CV-HDMI-4K-SC-1OUT-FF |
| 5 | Card overflow error — "HDMI 4K" qty 4 (2 cards) + "HDBaseT" qty 4 (2 cards) = 4 cards | error: "needs 4 cards but max 2" |
| 6 | Qty cap clamp — pick "HDBaseT" → qty input max=4. Type 6 → clamps to 4 |
| 7 | Add-row disable — at 2 rows, "+" button disabled with tooltip |
| 8 | Mutually exclusive signals — row 1 = "4K HDMI", row 2 dropdown should NOT show "4K HDMI" |
| 9 | Reset — fill form, click Reset → `_mvInputRows` back to `[{signal:'', qty:1}]`, output back to "4K HDMI" |
| 10 | Edit-restore — save a mixed-input MV deal in v26.4. Refresh app. Open History. Click Edit. Form restores exactly with both rows. |
| **11 (NEW)** | **MWP-4Hi-1Y trigger** — "FHD HDMI" qty 4 + "AVIP" qty 2 + output "4K HDMI" | **recommends MWP-4Hi-1Y (fixed-mixed), NOT MWP-MTO** |
| **12 (NEW)** | **MWP-4Hi-1Y boundary** — "FHD HDMI" qty 4 + "AVIP" qty 2 + "HDBaseT" qty 1 + output "4K HDMI" | recommends MWP-MTO (3 signal types — MWP-4Hi-1Y disqualified) — but wait, this hits the 2-row cap, so user can't even enter 3 rows. Replace test 12 with: "FHD HDMI" qty 5 + "AVIP" qty 1 + output "4K HDMI" → recommends MWP-MTO (fhdQty > 4 disqualifies MWP-4Hi-1Y) |
| **13 (NEW)** | **AVIP qty cap** — pick "AVIP" → qty input max=4. Type 6 → clamps to 4 |
| **14 (NEW)** | **HDMI 1080p output dropped** — output dropdown shows exactly 4 options (4K HDMI, DVI-I, 3G SDI, HDBaseT). HDMI 1080p NOT present. |
| **15 (NEW)** | **SDI 3G card-size selection** — pick "3G-SDI" qty 2 + output "4K HDMI" → MWP-MTO + CV-3GSDI-2IN-FF (2-port preferred); change qty to 3 → CV-3GSDI-4IN-FF (escalates) |

---

## 8. Out of scope for v26.4.0

- CORIO wizard (v26.7.0 — separate spec)
- CALICO Cards 02/03/04 (v26.5.0 — separate spec)
- Signal Extension sub-wizards (v26.6.0 — separate spec; the Yes/No trigger at the bottom of MV is wired up in v26.6, not v26.4)
- Fiber MG-FB-* wizard (Phase B)
- Encoder-100 (Phase B)
- HDBaseT 500-series (152m FHD — Phase B)

---

## 9. What v26.4.0 ship looks like

1. Insert revised mvWizardCard HTML (§5) replacing v26.3.1's current content
2. Update existing `CORIOVIEW_CHASSIS` catalog (v26.3.1 L7597) — add MWP-4Hi-1Y row with `mixed:true` shape
3. Update existing `CORIOVIEW_INPUT_CARDS` (v26.3.1 L7607) — convert each value from object to array; add AVIP entry; add SDI 3G 2-port option
4. Update existing `CORIOVIEW_OUTPUT_CARDS` (v26.3.1 L7617) — remove HDMI 1080p entry
5. Update existing `MV_QTY_CAP` (v26.3.1 L7628) — add `AVIP: 4`
6. Update existing `recommendMWP()` (v26.3.1 L9697) — add STEP 2 mixed-fixed match block + `pickMinCard` helper
7. Add 5 new row-management functions: `_mvRenderInputRows`, `_mvOnSignalChange`, `_mvOnQtyChange`, `_mvAddInputRow`, `_mvRemoveInputRow`
8. Update existing `_mvRecompute()` (v26.3.1 L9879) — handle new `type:'fixed-mixed'` result
9. Bump version: `26.3.1` → `26.4.0` with inline changelog entry
10. `node --check` on extracted script
11. Deliver `index.html` to `/mnt/user-data/outputs/`

**Estimated effort: 1 focused session, ~400-500 lines net add. No DB change. No backend change.**

---

*End of MV-SPEC-v26.4.0 REVISED. Source: voice clarification with Dipenkumar 2026-05-21 + 2026-05-22 + extraction from v25.118.0 git commit 2ba47bb.*
